# HotelPro API Documentation

Base URL (local): `http://localhost:5000/api`
Auth: send `Authorization: Bearer <JWT>` on protected routes.
All responses are JSON: `{ "success": true|false, ... }`. Errors look like:

```json
{ "success": false, "message": "Validation failed", "errors": [{ "field": "email", "message": "A valid email is required" }] }
```

| Status | Meaning |
|---|---|
| 200 / 201 | OK / Created |
| 400 | Validation error or invalid request |
| 401 | Missing, invalid or expired token; wrong credentials |
| 403 | Authenticated but not allowed (role, deactivated account, not your booking) |
| 404 | Resource not found |
| 409 | Conflict (duplicate email, room sold out, delete blocked by upcoming bookings) |
| 429 | Too many auth attempts |
| 500 | Server error |

Roles: **public**, **customer** (any logged-in user), **admin**.

## Health
| Method | Path | Access | Description |
|---|---|---|---|
| GET | `/health` | public | Service status and payment mode (`razorpay` or `simulated`) |

## Auth (`/auth`)
| Method | Path | Access | Body | Description |
|---|---|---|---|---|
| POST | `/auth/register` | public | `name, email, password(min 6), phone?` | Creates a customer, returns `token` + `user` |
| POST | `/auth/login` | public | `email, password` | Returns `token` + `user` |
| POST | `/auth/admin-login` | public | `email, password` | Same, but only admins accepted (403 otherwise) |
| GET | `/auth/me` | customer | - | Current user |

## Users (`/users`)
| Method | Path | Access | Description |
|---|---|---|---|
| PUT | `/users/profile` | customer | Update `name, email, phone, address` |
| PUT | `/users/password` | customer | `currentPassword, newPassword` |
| GET | `/users?search=&page=&limit=` | admin | Customers with `bookingCount` and `totalSpent` |
| GET | `/users/:id` | admin | Customer + full booking history |
| PUT | `/users/:id` | admin | Edit guest record: `name, phone, address, isActive` |

## Hotels (`/hotels`)
| Method | Path | Access | Description |
|---|---|---|---|
| GET | `/hotels` | public | Query: `search, city, minPrice, maxPrice, rating, featured, sort(price_asc, price_desc, rating, newest), checkIn, checkOut, guests, page, limit`. With dates, only hotels with a free room are returned |
| GET | `/hotels/destinations` | public | Top cities with hotel count and lowest price |
| GET | `/hotels/:id?checkIn=&checkOut=` | public | Hotel + rooms; each room gets `available` (free units) when dates are given |
| GET | `/hotels/:hotelId/rooms` | public | Active rooms of a hotel |
| GET | `/hotels/admin/all` | admin | All hotels incl. hidden, with `roomCount` |
| POST | `/hotels` | admin | `name, description, city, address` (+ `state, country, starRating, rating, amenities[], images[], featured, isActive`) |
| PUT | `/hotels/:id` | admin | Update any hotel field |
| DELETE | `/hotels/:id` | admin | Deletes hotel and rooms. **409** if upcoming active bookings exist |
| POST | `/hotels/:id/images` | admin | `multipart/form-data`, field `images` (max 8 files, 5 MB each) |
| DELETE | `/hotels/:id/images?url=` | admin | Remove an image |

## Rooms (`/rooms`)
| Method | Path | Access | Description |
|---|---|---|---|
| GET | `/rooms/:id` | public | Room details |
| GET | `/rooms/:id/availability?checkIn=&checkOut=&guests=` | public | `{ available, unitsLeft, nights, pricePerNight, totalPrice }` |
| GET | `/rooms?hotel=` | admin | All rooms |
| POST | `/rooms` | admin | `hotel, name, pricePerNight` + `category, capacity, quantity, bedType, sizeSqFt, amenities, images, description` |
| PUT | `/rooms/:id` | admin | Update room |
| PATCH | `/rooms/:id/price` | admin | `{ pricePerNight }` |
| DELETE | `/rooms/:id` | admin | **409** if upcoming active bookings |
| POST | `/rooms/:id/images` | admin | multipart upload |

## Bookings (`/bookings`)
| Method | Path | Access | Description |
|---|---|---|---|
| POST | `/bookings` | customer | `roomId, checkIn, checkOut, guests, guestName?, guestPhone?, specialRequests?` → creates `pending` booking with unique `bookingId` (e.g. `HP-20261101-A1B2C`). **409** if sold out |
| GET | `/bookings/my?status=` | customer | Own bookings |
| GET | `/bookings/:id` | owner/admin | Booking (Mongo `_id` or `HP-…` ID) + latest payment |
| PATCH | `/bookings/:id/cancel` | owner/admin | Cancels; auto-refunds a successful payment |
| GET | `/bookings?status=&hotel=&search=&page=&limit=` | admin | All reservations |
| PATCH | `/bookings/:id/status` | admin | `{ status: pending|confirmed|completed|cancelled }` |

### How double booking is prevented
1. Dates are validated (check-in not in the past, check-out after check-in, max 30 nights).
2. The booking runs in a **MongoDB transaction**. The room document is updated first (`$inc bookingVersion`), so two simultaneous bookings of the same room conflict; MongoDB retries the loser, which then sees the winner's booking.
3. Overlap rule: `existing.checkIn < new.checkOut AND existing.checkOut > new.checkIn`. A room type with `quantity` N is free if, on every night of the stay, fewer than N active (`pending`/`confirmed`) bookings cover that night.
4. Standalone MongoDB without a replica set cannot run transactions; the code then falls back to the same checks without a transaction (MongoDB Atlas always supports transactions).

## Payments (`/payments`)
| Method | Path | Access | Description |
|---|---|---|---|
| GET | `/payments/config` | public | `{ mode: "razorpay"|"simulated", keyId }` |
| POST | `/payments/create-order` | customer | `{ bookingId }` (Mongo `_id`) → payment record (+ Razorpay order when configured) |
| POST | `/payments/verify` | customer | Razorpay: `razorpay_order_id, razorpay_payment_id, razorpay_signature` (HMAC verified server-side) |
| POST | `/payments/simulate` | customer | **Simulated gateway only**: `{ paymentId, outcome: "success"|"failed" }`. Disabled when Razorpay keys are set |
| GET | `/payments/my` | customer | Payment history |
| GET | `/payments?status=&page=&limit=` | admin | All payments + totals per status |
| PATCH | `/payments/:id/refund` | admin | Refund a successful payment and cancel its booking |

Payment status: `pending`, `successful`, `failed`, `refunded`. A successful payment sets the booking to `confirmed`. Card details are never accepted or stored.

## Admin (`/admin`) - admin only
| Method | Path | Description |
|---|---|---|
| GET | `/admin/stats` | Totals, revenue, 6-month revenue series, bookings by status, occupancy, top hotels, recent bookings |
| GET | `/admin/revenue?from=&to=&groupBy=day|month` | Revenue series, payment totals by status, revenue per hotel |
| GET | `/admin/occupancy?days=30` | Today and forward-looking occupancy, per hotel |
