# Setup, GitHub and Deployment Guide

## 1. Run locally
```bash
# Backend
cd server
npm install
cp .env.example .env        # Windows: copy .env.example .env  -> then edit values
npm run seed                # loads sample hotels, rooms, users, bookings
npm run dev                 # http://localhost:5000

# Frontend (new terminal)
cd client
npm install
cp .env.example .env
npm run dev                 # http://localhost:5173
```
Seeded logins: **admin** `admin@hotelpro.com` / `Admin@12345` (at `/admin/login`), **customer** `aarav@example.com` / `Customer@123`.

## 2. Connect MongoDB Atlas
1. Sign in at <https://cloud.mongodb.com> and create a free **M0** cluster.
2. **Database Access → Add New Database User**: choose a username and password (avoid special characters, or URL-encode them).
3. **Network Access → Add IP Address**: add your IP for development. For Render, use `0.0.0.0/0` (allow from anywhere), since free Render has no fixed IP. The database user's password is then your protection.
4. **Database → Connect → Drivers**: copy the connection string and insert the database name:
   `mongodb+srv://<user>:<password>@cluster0.xxxxx.mongodb.net/hotelpro?retryWrites=true&w=majority`
5. Paste it as `MONGO_URI` in `server/.env`, then run `npm run seed` once.
6. Check **Browse Collections** to see `users`, `hotels`, `rooms`, `bookings`, `payments`.

## 3. Upload to GitHub
```bash
cd HotelPro
git init
git add .
git commit -m "HotelPro: MERN hotel booking and management system"
git branch -M main
# create an empty repository on github.com first (no README), then:
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
Before pushing, confirm `git status` does **not** list any `.env` file (the `.gitignore` already excludes them). If a secret was ever committed, rotate it.

## 4. Deploy the backend on Render
1. <https://render.com> → **New → Web Service** → connect your GitHub repository.
2. Settings: **Root Directory** `server`, **Runtime** Node, **Build Command** `npm install`, **Start Command** `npm start`.
3. **Environment variables**:
   | Key | Value |
   |---|---|
   | `NODE_ENV` | `production` |
   | `MONGO_URI` | your Atlas string |
   | `JWT_SECRET` | long random string (`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`) |
   | `CLIENT_URL` | your Vercel URL, e.g. `https://hotelpro.vercel.app` (add after step 5; no trailing slash; comma-separate multiple) |
   | `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` | optional, test keys |
4. Deploy, then open `https://<service>.onrender.com/api/health`.
5. Seed the cloud database from your computer (point `server/.env` at Atlas and run `npm run seed`).

Notes: the free tier sleeps after inactivity (first request is slow). Files uploaded through the admin panel are stored on Render's temporary disk and disappear on redeploy; for permanent images paste image URLs in the admin form (or integrate Cloudinary, see Future Scope).

## 5. Deploy the frontend on Vercel
1. <https://vercel.com> → **Add New → Project** → import the same repository.
2. **Root Directory** `client`, Framework **Vite**, Build `npm run build`, Output `dist`.
3. Environment variable: `VITE_API_URL` = `https://<service>.onrender.com/api`
4. Deploy. `client/vercel.json` makes React Router deep links work on refresh.
5. Copy the Vercel URL into Render's `CLIENT_URL` and redeploy the backend (CORS).

## 6. Razorpay test mode (optional)
Create a Razorpay account, switch to **Test Mode**, generate API keys, put them in `server/.env`, restart. `/api/health` will show `paymentMode: "razorpay"` and checkout opens Razorpay's test popup (use Razorpay's published test card/UPI details). Without keys the clearly-labelled simulated gateway is used.
