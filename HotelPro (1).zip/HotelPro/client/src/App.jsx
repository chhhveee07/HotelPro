import { Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProtectedRoute from './components/ProtectedRoute';
import AdminLayout from './components/AdminLayout';

import Home from './pages/Home';
import HotelListings from './pages/HotelListings';
import HotelDetails from './pages/HotelDetails';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminLogin from './pages/AdminLogin';
import CustomerDashboard from './pages/CustomerDashboard';
import MyBookings from './pages/MyBookings';
import BookingDetails from './pages/BookingDetails';
import MyPayments from './pages/MyPayments';
import MyProfile from './pages/MyProfile';
import AdminDashboard from './pages/AdminDashboard';
import ManageHotels from './pages/ManageHotels';
import ManageRooms from './pages/ManageRooms';
import ManageBookings from './pages/ManageBookings';
import ManageGuests from './pages/ManageGuests';
import Payments from './pages/Payments';
import Reports from './pages/Reports';
import NotFound from './pages/NotFound';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => window.scrollTo(0, 0), [pathname]);
  return null;
}

const Public = ({ children }) => (
  <>
    <Navbar />
    <main className="page-min">{children}</main>
    <Footer />
  </>
);

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        {/* Public website */}
        <Route path="/" element={<Public><Home /></Public>} />
        <Route path="/hotels" element={<Public><HotelListings /></Public>} />
        <Route path="/hotels/:id" element={<Public><HotelDetails /></Public>} />
        <Route path="/login" element={<Public><Login /></Public>} />
        <Route path="/register" element={<Public><Register /></Public>} />

        {/* Customer area */}
        <Route path="/dashboard" element={<Public><ProtectedRoute><CustomerDashboard /></ProtectedRoute></Public>} />
        <Route path="/my-bookings" element={<Public><ProtectedRoute><MyBookings /></ProtectedRoute></Public>} />
        <Route path="/bookings/:id" element={<Public><ProtectedRoute><BookingDetails /></ProtectedRoute></Public>} />
        <Route path="/payments" element={<Public><ProtectedRoute><MyPayments /></ProtectedRoute></Public>} />
        <Route path="/profile" element={<Public><ProtectedRoute><MyProfile /></ProtectedRoute></Public>} />

        {/* Admin area */}
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/admin" element={<ProtectedRoute role="admin"><AdminLayout /></ProtectedRoute>}>
          <Route index element={<AdminDashboard />} />
          <Route path="hotels" element={<ManageHotels />} />
          <Route path="rooms" element={<ManageRooms />} />
          <Route path="bookings" element={<ManageBookings />} />
          <Route path="guests" element={<ManageGuests />} />
          <Route path="payments" element={<Payments />} />
          <Route path="reports" element={<Reports />} />
        </Route>

        <Route path="*" element={<Public><NotFound /></Public>} />
      </Routes>
    </>
  );
}
