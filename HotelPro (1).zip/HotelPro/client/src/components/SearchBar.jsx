import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { dateInput } from '../utils';

export default function SearchBar({ initial = {}, compact = false }) {
  const navigate = useNavigate();
  const [f, setF] = useState({
    search: initial.search || '',
    checkIn: initial.checkIn || dateInput(1),
    checkOut: initial.checkOut || dateInput(3),
    guests: initial.guests || 2,
  });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = (e) => {
    e.preventDefault();
    const q = new URLSearchParams();
    if (f.search.trim()) q.set('search', f.search.trim());
    if (f.checkIn && f.checkOut) { q.set('checkIn', f.checkIn); q.set('checkOut', f.checkOut); }
    q.set('guests', f.guests);
    navigate(`/hotels?${q.toString()}`);
  };

  return (
    <form className={`hp-search ${compact ? 'hp-search-compact' : ''}`} onSubmit={submit}>
      <div className="row g-2 align-items-end">
        <div className="col-12 col-lg-4">
          <label className="form-label" htmlFor="s-dest">Where to?</label>
          <input id="s-dest" className="form-control" placeholder="City or hotel name" value={f.search} onChange={set('search')} />
        </div>
        <div className="col-6 col-lg-2">
          <label className="form-label" htmlFor="s-in">Check-in</label>
          <input id="s-in" type="date" className="form-control" min={dateInput(0)} value={f.checkIn} onChange={(e) => {
            const v = e.target.value;
            setF((p) => ({ ...p, checkIn: v, checkOut: p.checkOut <= v ? new Date(new Date(v).getTime() + 86400000).toISOString().slice(0, 10) : p.checkOut }));
          }} />
        </div>
        <div className="col-6 col-lg-2">
          <label className="form-label" htmlFor="s-out">Check-out</label>
          <input id="s-out" type="date" className="form-control" min={f.checkIn} value={f.checkOut} onChange={set('checkOut')} />
        </div>
        <div className="col-6 col-lg-2">
          <label className="form-label" htmlFor="s-g">Guests</label>
          <select id="s-g" className="form-select" value={f.guests} onChange={set('guests')}>
            {[1, 2, 3, 4, 5, 6].map((n) => <option key={n} value={n}>{n} guest{n > 1 ? 's' : ''}</option>)}
          </select>
        </div>
        <div className="col-6 col-lg-2">
          <button className="btn btn-gold w-100" type="submit">Search hotels</button>
        </div>
      </div>
    </form>
  );
}
