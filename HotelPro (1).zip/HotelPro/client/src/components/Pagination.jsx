export default function Pagination({ page, pages, onChange }) {
  if (!pages || pages <= 1) return null;
  return (
    <nav className="d-flex justify-content-center gap-1 mt-4" aria-label="Pagination">
      <button className="btn btn-sm btn-outline-secondary" disabled={page <= 1} onClick={() => onChange(page - 1)}>Previous</button>
      {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
        <button key={p} className={`btn btn-sm ${p === page ? 'btn-hp' : 'btn-outline-secondary'}`} onClick={() => onChange(p)}>{p}</button>
      ))}
      <button className="btn btn-sm btn-outline-secondary" disabled={page >= pages} onClick={() => onChange(page + 1)}>Next</button>
    </nav>
  );
}
