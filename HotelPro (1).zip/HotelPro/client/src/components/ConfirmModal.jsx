export default function ConfirmModal({ show, title, message, confirmText = 'Confirm', danger = false, busy = false, onConfirm, onCancel }) {
  if (!show) return null;
  return (
    <div className="hp-modal-backdrop" onClick={onCancel}>
      <div className="hp-modal" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
        <h5 className="mb-2">{title}</h5>
        <p className="text-muted mb-4">{message}</p>
        <div className="d-flex justify-content-end gap-2">
          <button className="btn btn-outline-secondary" onClick={onCancel} disabled={busy}>Keep it</button>
          <button className={`btn ${danger ? 'btn-danger' : 'btn-hp'}`} onClick={onConfirm} disabled={busy}>
            {busy ? 'Please wait…' : confirmText}
          </button>
        </div>
      </div>
    </div>
  );
}
