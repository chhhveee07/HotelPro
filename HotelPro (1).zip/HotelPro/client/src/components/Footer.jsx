import { Link } from 'react-router-dom';
import Logo from './Logo';

export default function Footer() {
  return (
    <footer className="hp-footer">
      <div className="container">
        <div className="row g-4">
          <div className="col-lg-4">
            <Logo light />
            <p className="mt-3 small opacity-75">Find a room, pick your dates and book in minutes. HotelPro connects travellers with hotels across India.</p>
          </div>
          <div className="col-6 col-lg-2">
            <h6>Explore</h6>
            <ul className="list-unstyled small">
              <li><Link to="/hotels">All hotels</Link></li>
              <li><Link to="/hotels?city=Goa">Goa</Link></li>
              <li><Link to="/hotels?city=Mumbai">Mumbai</Link></li>
              <li><Link to="/hotels?city=Jaipur">Jaipur</Link></li>
            </ul>
          </div>
          <div className="col-6 col-lg-2">
            <h6>Account</h6>
            <ul className="list-unstyled small">
              <li><Link to="/login">Log in</Link></li>
              <li><Link to="/register">Create account</Link></li>
              <li><Link to="/my-bookings">My bookings</Link></li>
              <li><Link to="/admin/login">Admin sign in</Link></li>
            </ul>
          </div>
          <div className="col-lg-4">
            <h6>Contact</h6>
            <p className="small opacity-75 mb-1">support@hotelpro.example</p>
            <p className="small opacity-75">+91 90000 00000</p>
            <p className="small opacity-75 mb-0">Academic project. Payments run in test or simulated mode.</p>
          </div>
        </div>
        <hr className="opacity-25 my-4" />
        <p className="small opacity-50 mb-0">© {new Date().getFullYear()} HotelPro. All rights reserved.</p>
      </div>
    </footer>
  );
}
