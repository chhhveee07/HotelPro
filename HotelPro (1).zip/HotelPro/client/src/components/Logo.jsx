export default function Logo({ light = false }) {
  return (
    <span className="hp-logo" style={{ color: light ? '#fff' : 'var(--navy)' }}>
      <svg width="30" height="30" viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" rx="14" fill={light ? '#D9BE7F' : '#0B1F3A'} />
        <path d="M18 46V18h6v10h16V18h6v28h-6V34H24v12z" fill={light ? '#0B1F3A' : '#D9BE7F'} />
      </svg>
      <span>Hotel<b>Pro</b></span>
    </span>
  );
}
