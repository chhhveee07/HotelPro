// Lightweight dependency-free SVG charts for the admin dashboard.
import { inr } from '../utils';

export function BarChart({ data, valueKey = 'revenue', labelKey = 'label', height = 220, money = true }) {
  const max = Math.max(...data.map((d) => d[valueKey]), 1);
  const w = 100 / Math.max(data.length, 1);
  return (
    <div className="hp-chart">
      <svg viewBox={`0 0 100 ${height / 4}`} preserveAspectRatio="none" style={{ width: '100%', height }} role="img" aria-label="Bar chart">
        {[0.25, 0.5, 0.75, 1].map((g) => <line key={g} x1="0" x2="100" y1={(height / 4) * (1 - g)} y2={(height / 4) * (1 - g)} stroke="#E5E0D3" strokeWidth="0.3" />)}
        {data.map((d, i) => {
          const h = (d[valueKey] / max) * (height / 4 - 4);
          return <rect key={i} x={i * w + w * 0.2} y={height / 4 - h} width={w * 0.6} height={h} rx="0.8" fill="#0B1F3A"><title>{`${d[labelKey]}: ${money ? inr(d[valueKey]) : d[valueKey]}`}</title></rect>;
        })}
      </svg>
      <div className="d-flex">
        {data.map((d, i) => (
          <div key={i} className="text-center small text-muted" style={{ width: `${w}%` }}>
            {d[labelKey]}
            <div className="fw-semibold text-dark" style={{ fontSize: 11 }}>{money ? inr(d[valueKey]) : d[valueKey]}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Donut({ data, size = 160 }) {
  const colors = { confirmed: '#2F7D5B', pending: '#C9962B', completed: '#0B1F3A', cancelled: '#B5483B' };
  const total = data.reduce((s, d) => s + d.count, 0) || 1;
  let acc = 0;
  const r = 15.9155;
  return (
    <div className="d-flex align-items-center gap-4 flex-wrap">
      <svg width={size} height={size} viewBox="0 0 42 42" role="img" aria-label="Bookings by status">
        <circle cx="21" cy="21" r={r} fill="none" stroke="#EFE8D8" strokeWidth="6" />
        {data.map((d) => {
          const pct = (d.count / total) * 100;
          const el = <circle key={d.status} cx="21" cy="21" r={r} fill="none" stroke={colors[d.status] || '#999'} strokeWidth="6" strokeDasharray={`${pct} ${100 - pct}`} strokeDashoffset={25 - acc} />;
          acc += pct;
          return el;
        })}
        <text x="21" y="22.5" textAnchor="middle" fontSize="6" fontWeight="700" fill="#0B1F3A">{total}</text>
      </svg>
      <ul className="list-unstyled mb-0 small">
        {data.map((d) => (
          <li key={d.status} className="d-flex align-items-center gap-2 mb-1">
            <span style={{ width: 10, height: 10, borderRadius: 2, background: colors[d.status] || '#999' }} />
            <span className="text-capitalize">{d.status}</span>
            <strong className="ms-auto ps-3">{d.count}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function ProgressRow({ label, sub, percent }) {
  return (
    <div className="mb-3">
      <div className="d-flex justify-content-between small">
        <span><strong>{label}</strong> <span className="text-muted">{sub}</span></span>
        <strong>{percent}%</strong>
      </div>
      <div className="hp-progress"><div style={{ width: `${Math.min(percent, 100)}%` }} /></div>
    </div>
  );
}
