export default function StarRating({ value = 0, count, size = 14 }) {
  return (
    <span className="hp-rating" title={`${value} out of 5`}>
      <span className="hp-rating-badge" style={{ fontSize: size }}>{Number(value).toFixed(1)}</span>
      {count !== undefined && <small className="text-muted ms-2">{count.toLocaleString('en-IN')} reviews</small>}
    </span>
  );
}

export const Stars = ({ n = 0 }) => (
  <span className="hp-stars" aria-label={`${n} star hotel`}>{'★'.repeat(n)}<span className="off">{'★'.repeat(5 - n)}</span></span>
);
