export default function Loader({ full = false, text = 'Loading…' }) {
  return (
    <div className={`hp-loader ${full ? 'hp-loader-full' : ''}`} role="status">
      <div className="spinner-border" style={{ color: 'var(--gold)' }} />
      <span className="ms-3 text-muted">{text}</span>
    </div>
  );
}
