export default function Modal({ show, title, onClose, children, size = 'md' }) {
  if (!show) return null;
  return (
    <div className="hp-modal-backdrop" onMouseDown={onClose}>
      <div className={`hp-modal hp-modal-${size}`} role="dialog" aria-modal="true" onMouseDown={(e) => e.stopPropagation()}>
        <div className="d-flex justify-content-between align-items-start mb-3">
          <h5 className="mb-0">{title}</h5>
          <button className="btn-close" aria-label="Close" onClick={onClose} />
        </div>
        {children}
      </div>
    </div>
  );
}
