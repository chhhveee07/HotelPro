import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Logo from './Logo';

export default function Navbar() {
  const { user, isAdmin, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const close = () => setOpen(false);

  const doLogout = () => {
    logout();
    close();
    navigate('/');
  };

  return (
    <header className="hp-nav">
      <div className="container d-flex align-items-center justify-content-between">
        <Link to="/" onClick={close} className="text-decoration-none"><Logo /></Link>
        <button className="hp-nav-toggle d-lg-none" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}>
          <span /><span /><span />
        </button>
        <nav className={`hp-nav-links ${open ? 'open' : ''}`}>
          <NavLink to="/" end onClick={close}>Home</NavLink>
          <NavLink to="/hotels" onClick={close}>Hotels</NavLink>
          {user && !isAdmin && <NavLink to="/my-bookings" onClick={close}>My bookings</NavLink>}
          {user && !isAdmin && <NavLink to="/dashboard" onClick={close}>Dashboard</NavLink>}
          {isAdmin && <NavLink to="/admin" onClick={close}>Admin panel</NavLink>}
          <span className="hp-nav-spacer" />
          {user ? (
            <>
              <Link to={isAdmin ? '/admin' : '/profile'} onClick={close} className="hp-nav-user">{user.name.split(' ')[0]}</Link>
              <button className="btn btn-outline-light btn-sm" onClick={doLogout}>Log out</button>
            </>
          ) : (
            <>
              <NavLink to="/login" onClick={close}>Log in</NavLink>
              <Link to="/register" onClick={close} className="btn btn-gold btn-sm">Sign up</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
