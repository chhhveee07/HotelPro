import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Logo from './Logo';

const links = [
  ['/admin', 'Dashboard', true],
  ['/admin/hotels', 'Manage hotels'],
  ['/admin/rooms', 'Manage rooms'],
  ['/admin/bookings', 'Reservations'],
  ['/admin/guests', 'Guests'],
  ['/admin/payments', 'Payments'],
  ['/admin/reports', 'Reports'],
];

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  return (
    <div className="admin-shell">
      <aside className={`admin-side ${open ? 'open' : ''}`}>
        <div className="px-3 py-4"><Logo light /><div className="small opacity-50 mt-1">Admin console</div></div>
        <nav className="flex-grow-1">
          {links.map(([to, label, end]) => (
            <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)}>{label}</NavLink>
          ))}
          <NavLink to="/" onClick={() => setOpen(false)} className="mt-3">View website</NavLink>
        </nav>
        <div className="p-3 border-top border-secondary border-opacity-25 small">
          <div className="mb-2 opacity-75">{user?.name}</div>
          <button className="btn btn-outline-light btn-sm w-100" onClick={() => { logout(); navigate('/admin/login'); }}>Log out</button>
        </div>
      </aside>
      <div className="admin-main">
        <div className="admin-topbar d-lg-none">
          <button className="btn btn-sm btn-hp" onClick={() => setOpen(!open)}>Menu</button>
          <strong>HotelPro Admin</strong>
        </div>
        <div className="admin-content"><Outlet /></div>
      </div>
    </div>
  );
}
