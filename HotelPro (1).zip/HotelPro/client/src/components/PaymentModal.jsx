import { useEffect, useState } from 'react';
import Modal from './Modal';
import { paymentService, errMsg } from '../services/api-helpers';
import { inr } from '../utils';

const loadRazorpay = () =>
  new Promise((resolve, reject) => {
    if (window.Razorpay) return resolve(true);
    const s = document.createElement('script');
    s.src = 'https://checkout.razorpay.com/v1/checkout.js';
    s.onload = () => resolve(true);
    s.onerror = () => reject(new Error('Could not load Razorpay checkout'));
    document.body.appendChild(s);
  });

/**
 * Pays for a pending booking.
 *  - Razorpay configured on the server -> opens Razorpay Checkout (test mode keys).
 *  - Otherwise -> clearly labelled SIMULATED gateway. No card details are ever collected or stored.
 */
export default function PaymentModal({ booking, user, show, onClose, onDone }) {
  const [state, setState] = useState({ mode: null, payment: null, order: null, keyId: null });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!show) return;
    setError(''); setState({ mode: null, payment: null, order: null, keyId: null });
    paymentService.createOrder(booking._id)
      .then((d) => setState({ mode: d.mode, payment: d.payment, order: d.order, keyId: d.keyId }))
      .catch((e) => setError(errMsg(e)));
  }, [show, booking._id]);

  const simulate = async (outcome) => {
    setBusy(true); setError('');
    try {
      const d = await paymentService.simulate(state.payment._id, outcome);
      onDone(d.message, outcome === 'success');
    } catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };

  const razorpay = async () => {
    setBusy(true); setError('');
    try {
      await loadRazorpay();
      const rzp = new window.Razorpay({
        key: state.keyId,
        amount: state.order.amount,
        currency: state.order.currency,
        order_id: state.order.id,
        name: 'HotelPro',
        description: `Booking ${booking.bookingId}`,
        prefill: { name: user.name, email: user.email, contact: user.phone },
        theme: { color: '#0B1F3A' },
        handler: async (resp) => {
          try { const d = await paymentService.verify(resp); onDone(d.message, true); }
          catch (e) { setError(errMsg(e)); }
        },
        modal: { ondismiss: () => setBusy(false) },
      });
      rzp.on('payment.failed', (r) => { setError(r.error?.description || 'Payment failed'); setBusy(false); });
      rzp.open();
    } catch (e) { setError(e.message); setBusy(false); }
  };

  return (
    <Modal show={show} onClose={() => !busy && onClose()} title="Pay for your booking">
      <div className="bg-beige rounded p-3 mb-3">
        <div className="small text-muted">Booking {booking.bookingId}</div>
        <div className="fs-4 fw-bold" style={{ color: 'var(--navy)' }}>{inr(booking.totalPrice)}</div>
      </div>
      {error && <div className="alert alert-danger py-2">{error}</div>}
      {!state.mode && !error && <div className="text-muted">Preparing payment…</div>}

      {state.mode === 'simulated' && (
        <>
          <div className="sim-banner mb-3">
            <strong>Simulated payment.</strong> This is a demo gateway for the academic project. No real money moves and no card details are collected or stored.
          </div>
          <div className="d-grid gap-2">
            <button className="btn btn-gold" disabled={busy} onClick={() => simulate('success')}>Pay {inr(booking.totalPrice)} (simulate success)</button>
            <button className="btn btn-outline-danger" disabled={busy} onClick={() => simulate('failed')}>Simulate a failed payment</button>
          </div>
        </>
      )}

      {state.mode === 'razorpay' && (
        <>
          <div className="sim-banner mb-3">Secure checkout by Razorpay (test mode). Card details are handled by Razorpay and never reach HotelPro.</div>
          <button className="btn btn-gold w-100" disabled={busy} onClick={razorpay}>Pay {inr(booking.totalPrice)} with Razorpay</button>
        </>
      )}
    </Modal>
  );
}
