import { FALLBACK_IMG, imgUrl } from '../utils';

export default function Img({ src, alt = '', ...rest }) {
  return <img src={imgUrl(src) || FALLBACK_IMG} alt={alt} loading="lazy" onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = FALLBACK_IMG; }} {...rest} />;
}
