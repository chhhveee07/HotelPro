const MAP = {
  pending: 'warning', confirmed: 'success', completed: 'secondary', cancelled: 'danger',
  successful: 'success', failed: 'danger', refunded: 'info',
};
export default function StatusBadge({ status }) {
  return <span className={`hp-badge hp-badge-${MAP[status] || 'secondary'}`}>{status}</span>;
}
