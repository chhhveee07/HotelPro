import { Link } from 'react-router-dom';
import Img from './ImageWithFallback';
import StarRating, { Stars } from './StarRating';
import { inr } from '../utils';

export default function HotelCard({ hotel, query = '' }) {
  return (
    <Link to={`/hotels/${hotel._id}${query}`} className="hp-hotel-card text-decoration-none">
      <div className="hp-hotel-img">
        <Img src={hotel.images?.[0]} alt={hotel.name} />
        {hotel.featured && <span className="hp-tag">Featured</span>}
      </div>
      <div className="p-3">
        <div className="d-flex justify-content-between align-items-start gap-2">
          <h5 className="mb-1">{hotel.name}</h5>
          <StarRating value={hotel.rating} />
        </div>
        <div className="small text-muted mb-1">{hotel.city}, {hotel.state}</div>
        <Stars n={hotel.starRating} />
        <div className="d-flex flex-wrap gap-1 my-2">
          {(hotel.amenities || []).slice(0, 3).map((a) => <span key={a} className="hp-chip">{a}</span>)}
        </div>
        <div className="d-flex justify-content-between align-items-end">
          <small className="text-muted">{hotel.reviewCount?.toLocaleString('en-IN')} reviews</small>
          <div className="text-end">
            <small className="text-muted d-block">from</small>
            <strong className="hp-price">{inr(hotel.startingPrice)}</strong><small className="text-muted"> / night</small>
          </div>
        </div>
      </div>
    </Link>
  );
}
