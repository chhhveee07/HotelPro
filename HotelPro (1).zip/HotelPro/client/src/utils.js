import { FILE_URL } from './services/api';

export const inr = (n) => `₹${Number(n || 0).toLocaleString('en-IN')}`;

export const fmtDate = (d) =>
  d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' }) : '-';

// YYYY-MM-DD for <input type="date">, n days from today
export const dateInput = (offsetDays = 0) => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export const nightsBetween = (a, b) => (a && b ? Math.round((new Date(b) - new Date(a)) / 86400000) : 0);

// Uploaded images are served by the API; remote URLs are used as-is.
export const imgUrl = (src) => (!src ? '' : src.startsWith('/uploads') ? `${FILE_URL}${src}` : src);

export const FALLBACK_IMG =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="500"><rect width="100%" height="100%" fill="#E8DECA"/><text x="50%" y="50%" fill="#8A7A55" font-family="sans-serif" font-size="28" text-anchor="middle">HotelPro</text></svg>`
  );
