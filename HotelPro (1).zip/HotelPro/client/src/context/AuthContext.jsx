import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authService } from '../services';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(Boolean(localStorage.getItem('hp_token')));

  const logout = useCallback(() => {
    localStorage.removeItem('hp_token');
    setUser(null);
  }, []);

  // Restore session on page load
  useEffect(() => {
    if (!localStorage.getItem('hp_token')) return;
    authService
      .me()
      .then((d) => setUser(d.user))
      .catch(() => localStorage.removeItem('hp_token'))
      .finally(() => setLoading(false));
  }, []);

  // Interceptor fires this when the API returns 401 on a protected call
  useEffect(() => {
    window.addEventListener('hp:unauthorized', logout);
    return () => window.removeEventListener('hp:unauthorized', logout);
  }, [logout]);

  const handleAuth = (data) => {
    localStorage.setItem('hp_token', data.token);
    setUser(data.user);
    return data.user;
  };

  const value = useMemo(
    () => ({
      user,
      loading,
      isAdmin: user?.role === 'admin',
      login: async (body) => handleAuth(await authService.login(body)),
      adminLogin: async (body) => handleAuth(await authService.adminLogin(body)),
      register: async (body) => handleAuth(await authService.register(body)),
      logout,
      setUser,
    }),
    [user, loading, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
