import { useEffect, useState } from 'react';
import { adminService, errMsg } from '../services/api-helpers';
import Loader from '../components/Loader';
import { BarChart, ProgressRow } from '../components/Charts';
import { dateInput, inr } from '../utils';

export default function Reports() {
  const [from, setFrom] = useState(dateInput(-29));
  const [to, setTo] = useState(dateInput(0));
  const [groupBy, setGroupBy] = useState('day');
  const [rev, setRev] = useState(null);
  const [occ, setOcc] = useState(null);
  const [days, setDays] = useState(30);
  const [error, setError] = useState('');

  useEffect(() => { adminService.revenue({ from, to, groupBy }).then(setRev).catch((e) => setError(errMsg(e))); }, [from, to, groupBy]);
  useEffect(() => { adminService.occupancy({ days }).then((d) => setOcc(d.occupancy)).catch((e) => setError(errMsg(e))); }, [days]);

  const total = rev?.series.reduce((s, x) => s + x.revenue, 0) || 0;
  const t = (s) => rev?.totals.find((x) => x.status === s) || { total: 0, count: 0 };

  return (
    <>
      <h2 className="mb-1">Reports</h2>
      <p className="text-muted">Revenue and occupancy calculated from payment and booking records.</p>
      {error && <div className="alert alert-danger">{error}</div>}

      <div className="hp-panel mb-4">
        <div className="d-flex flex-wrap gap-3 align-items-end mb-3">
          <div><label className="form-label" htmlFor="r-from">From</label><input id="r-from" type="date" className="form-control" value={from} max={to} onChange={(e) => setFrom(e.target.value)} /></div>
          <div><label className="form-label" htmlFor="r-to">To</label><input id="r-to" type="date" className="form-control" value={to} min={from} onChange={(e) => setTo(e.target.value)} /></div>
          <div><label className="form-label" htmlFor="r-g">Group by</label><select id="r-g" className="form-select" value={groupBy} onChange={(e) => setGroupBy(e.target.value)}><option value="day">Day</option><option value="month">Month</option></select></div>
        </div>
        {!rev ? <Loader /> : (
          <>
            <div className="row g-3 mb-3">
              <div className="col-6 col-lg-3"><div className="stat-card"><div className="v">{inr(total)}</div><div className="l">Revenue in period</div></div></div>
              <div className="col-6 col-lg-3"><div className="stat-card"><div className="v">{t('successful').count}</div><div className="l">Successful payments</div></div></div>
              <div className="col-6 col-lg-3"><div className="stat-card"><div className="v">{inr(t('refunded').total)}</div><div className="l">Refunded</div></div></div>
              <div className="col-6 col-lg-3"><div className="stat-card"><div className="v">{t('failed').count}</div><div className="l">Failed payments</div></div></div>
            </div>
            {rev.series.length ? <div className="table-responsive"><div style={{ minWidth: Math.max(rev.series.length * 70, 300) }}><BarChart data={rev.series.map((s) => ({ ...s, label: s.period.slice(groupBy === 'day' ? 5 : 0) }))} /></div></div> : <p className="text-muted">No revenue recorded in this period.</p>}
            <h6 className="mt-4">Revenue by hotel</h6>
            <div className="table-responsive"><table className="table table-sm"><thead><tr><th>Hotel</th><th>City</th><th>Bookings</th><th>Nights sold</th><th className="text-end">Revenue</th></tr></thead>
              <tbody>{rev.byHotel.map((h) => <tr key={h.hotel}><td>{h.hotel}</td><td>{h.city}</td><td>{h.bookings}</td><td>{h.nights}</td><td className="text-end">{inr(h.revenue)}</td></tr>)}
                {!rev.byHotel.length && <tr><td colSpan="5" className="text-muted">No data.</td></tr>}</tbody></table></div>
          </>
        )}
      </div>

      <div className="hp-panel">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
          <h5 className="mb-0">Occupancy</h5>
          <select className="form-select w-auto" value={days} onChange={(e) => setDays(Number(e.target.value))} aria-label="Occupancy window">
            {[7, 14, 30, 60, 90].map((d) => <option key={d} value={d}>Next {d} days</option>)}
          </select>
        </div>
        {!occ ? <Loader /> : (
          <>
            <p className="text-muted">Today: <strong>{occ.occupiedToday}</strong> of <strong>{occ.totalUnits}</strong> rooms occupied ({occ.todayRate}%). Average over the next {occ.days} days: <strong>{occ.periodRate}%</strong>.</p>
            {occ.perHotel.map((h) => <ProgressRow key={h.hotelId} label={h.name} sub={`${h.city} · ${h.totalUnits} rooms`} percent={h.periodRate} />)}
          </>
        )}
      </div>
    </>
  );
}
