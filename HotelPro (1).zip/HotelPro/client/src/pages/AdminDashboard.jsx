import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { adminService, errMsg } from '../services/api-helpers';
import Loader from '../components/Loader';
import StatusBadge from '../components/StatusBadge';
import { BarChart, Donut, ProgressRow } from '../components/Charts';
import { fmtDate, inr } from '../utils';

export default function AdminDashboard() {
  const [s, setS] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => { adminService.stats().then((d) => setS(d.stats)).catch((e) => setError(errMsg(e))); }, []);

  if (error) return <div className="alert alert-danger">{error}</div>;
  if (!s) return <Loader />;

  const cards = [
    ['Total revenue', inr(s.totalRevenue)], ['Total bookings', s.totalBookings], ['Registered customers', s.totalCustomers],
    ['Hotels', s.totalHotels], ['Room types', s.totalRooms], ['Check-ins today', s.checkInsToday],
    ['Occupancy today', `${s.occupancy.todayRate}%`], ['30-day occupancy', `${s.occupancy.periodRate}%`],
  ];

  return (
    <>
      <h2 className="mb-1">Dashboard</h2>
      <p className="text-muted">Live figures from your database.</p>
      <div className="row g-3 mb-4">
        {cards.map(([l, v]) => <div className="col-6 col-xl-3" key={l}><div className="stat-card"><div className="v">{v}</div><div className="l">{l}</div></div></div>)}
      </div>

      <div className="row g-4 mb-4">
        <div className="col-xl-8"><div className="hp-panel h-100"><h5>Revenue, last 6 months</h5><BarChart data={s.monthlyRevenue} /></div></div>
        <div className="col-xl-4"><div className="hp-panel h-100"><h5>Bookings by status</h5>{s.bookingsByStatus.length ? <Donut data={s.bookingsByStatus} /> : <p className="text-muted">No bookings yet.</p>}</div></div>
      </div>

      <div className="row g-4">
        <div className="col-xl-5">
          <div className="hp-panel h-100">
            <h5>Occupancy by hotel <small className="text-muted fs-6">(next 30 days)</small></h5>
            {s.occupancy.perHotel.map((h) => <ProgressRow key={h.hotelId} label={h.name} sub={`${h.occupiedToday}/${h.totalUnits} rooms today`} percent={h.periodRate} />)}
          </div>
        </div>
        <div className="col-xl-7">
          <div className="hp-panel mb-4">
            <h5>Top hotels by revenue</h5>
            <div className="table-responsive"><table className="table table-sm mb-0"><thead><tr><th>Hotel</th><th>Bookings</th><th className="text-end">Revenue</th></tr></thead>
              <tbody>{s.topHotels.map((h) => <tr key={h.hotelId}><td>{h.name} <small className="text-muted">{h.city}</small></td><td>{h.bookings}</td><td className="text-end">{inr(h.revenue)}</td></tr>)}
                {!s.topHotels.length && <tr><td colSpan="3" className="text-muted">No paid bookings yet.</td></tr>}</tbody></table></div>
          </div>
          <div className="hp-panel">
            <div className="d-flex justify-content-between"><h5>Recent bookings</h5><Link to="/admin/bookings">View all</Link></div>
            <div className="table-responsive"><table className="table table-sm mb-0"><tbody>
              {s.recentBookings.map((b) => <tr key={b._id}><td><strong>{b.bookingId}</strong></td><td>{b.user?.name}</td><td>{b.hotel?.name}</td><td>{fmtDate(b.checkIn)}</td><td><StatusBadge status={b.status} /></td><td className="text-end">{inr(b.totalPrice)}</td></tr>)}
            </tbody></table></div>
          </div>
        </div>
      </div>
    </>
  );
}
