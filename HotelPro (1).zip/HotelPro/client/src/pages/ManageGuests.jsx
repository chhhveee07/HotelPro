import { useEffect, useState } from 'react';
import { userService, errMsg } from '../services/api-helpers';
import { useToast } from '../context/ToastContext';
import Loader from '../components/Loader';
import Modal from '../components/Modal';
import Pagination from '../components/Pagination';
import StatusBadge from '../components/StatusBadge';
import { fmtDate, inr } from '../utils';

export default function ManageGuests() {
  const toast = useToast();
  const [data, setData] = useState({ users: [], total: 0, pages: 1 });
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [detail, setDetail] = useState(null); // { user, bookings }
  const [form, setForm] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = () => userService.list({ search, page, limit: 15 }).then(setData).catch((e) => toast.error(errMsg(e))).finally(() => setLoading(false));
  useEffect(() => { setLoading(true); load(); /* eslint-disable-next-line */ }, [page]);

  const open = async (u) => {
    try { const d = await userService.get(u._id); setDetail(d); setForm({ name: d.user.name, phone: d.user.phone || '', address: d.user.address || '', isActive: d.user.isActive }); }
    catch (e) { toast.error(errMsg(e)); }
  };

  const save = async (e) => {
    e.preventDefault(); setBusy(true);
    try { await userService.update(detail.user._id, form); toast.success('Guest record updated'); setDetail(null); load(); }
    catch (er) { toast.error(errMsg(er)); } finally { setBusy(false); }
  };

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div><h2 className="mb-0">Guests</h2><p className="text-muted mb-0">{data.total} registered customer(s)</p></div>
        <form className="d-flex gap-2" onSubmit={(e) => { e.preventDefault(); setPage(1); setLoading(true); load(); }}>
          <input className="form-control" placeholder="Name, email or phone" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search guests" />
          <button className="btn btn-hp">Search</button>
        </form>
      </div>
      {loading ? <Loader /> : (
        <div className="hp-table table-responsive">
          <table className="table table-hover">
            <thead><tr><th>Guest</th><th>Phone</th><th>Joined</th><th>Bookings</th><th className="text-end">Total spent</th><th>Account</th><th></th></tr></thead>
            <tbody>
              {data.users.map((u) => (
                <tr key={u._id}>
                  <td><strong>{u.name}</strong><div className="small text-muted">{u.email}</div></td>
                  <td>{u.phone || '-'}</td><td>{fmtDate(u.createdAt)}</td><td>{u.bookingCount}</td><td className="text-end">{inr(u.totalSpent)}</td>
                  <td><span className={`hp-badge ${u.isActive ? 'hp-badge-success' : 'hp-badge-danger'}`}>{u.isActive ? 'active' : 'deactivated'}</span></td>
                  <td className="text-end"><button className="btn btn-sm btn-outline-hp" onClick={() => open(u)}>View / edit</button></td>
                </tr>
              ))}
              {!data.users.length && <tr><td colSpan="7" className="text-center text-muted py-4">No guests found.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} pages={data.pages} onChange={setPage} />

      <Modal show={!!detail} size="lg" title={detail ? `Guest record: ${detail.user.email}` : ''} onClose={() => !busy && setDetail(null)}>
        {detail && form && (
          <>
            <form onSubmit={save}>
              <div className="row g-3">
                <div className="col-md-6"><label className="form-label">Name</label><input className="form-control" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div className="col-md-6"><label className="form-label">Phone</label><input className="form-control" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
                <div className="col-12"><label className="form-label">Address</label><input className="form-control" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
                <div className="col-12"><div className="form-check form-switch"><input id="g-act" type="checkbox" className="form-check-input" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /><label htmlFor="g-act" className="form-check-label">Account active (deactivated guests cannot log in)</label></div></div>
              </div>
              <div className="text-end mt-3"><button className="btn btn-hp" disabled={busy}>Save record</button></div>
            </form>
            <h6 className="mt-4">Booking history ({detail.bookings.length})</h6>
            <div className="table-responsive"><table className="table table-sm"><tbody>
              {detail.bookings.map((b) => <tr key={b._id}><td>{b.bookingId}</td><td>{b.hotel?.name}</td><td>{fmtDate(b.checkIn)}</td><td>{inr(b.totalPrice)}</td><td><StatusBadge status={b.status} /></td></tr>)}
              {!detail.bookings.length && <tr><td className="text-muted">No bookings yet.</td></tr>}
            </tbody></table></div>
          </>
        )}
      </Modal>
    </>
  );
}
