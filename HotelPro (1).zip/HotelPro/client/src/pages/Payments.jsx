import { useEffect, useState } from 'react';
import { paymentService, errMsg } from '../services/api-helpers';
import { useToast } from '../context/ToastContext';
import Loader from '../components/Loader';
import StatusBadge from '../components/StatusBadge';
import Pagination from '../components/Pagination';
import ConfirmModal from '../components/ConfirmModal';
import { fmtDate, inr } from '../utils';

export default function Payments() {
  const toast = useToast();
  const [data, setData] = useState({ payments: [], summary: [], pages: 1 });
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [refund, setRefund] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = () => paymentService.adminAll({ status, page, limit: 15 }).then(setData).catch((e) => toast.error(errMsg(e))).finally(() => setLoading(false));
  useEffect(() => { setLoading(true); load(); /* eslint-disable-next-line */ }, [status, page]);

  const doRefund = async () => {
    setBusy(true);
    try { const d = await paymentService.refund(refund._id); toast.success(d.message); load(); }
    catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); setRefund(null); }
  };
  const sum = (s) => data.summary.find((x) => x._id === s) || { total: 0, count: 0 };

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div><h2 className="mb-0">Payments</h2><p className="text-muted mb-0">Payment records. Card details are never stored.</p></div>
        <select className="form-select w-auto" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} aria-label="Filter by status">
          <option value="">All statuses</option>{['pending', 'successful', 'failed', 'refunded'].map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>
      <div className="row g-3 mb-4">
        {['successful', 'pending', 'failed', 'refunded'].map((s) => (
          <div className="col-6 col-lg-3" key={s}><div className="stat-card"><div className="v">{inr(sum(s).total)}</div><div className="l text-capitalize">{s} · {sum(s).count} payment(s)</div></div></div>
        ))}
      </div>
      {loading ? <Loader /> : (
        <div className="hp-table table-responsive">
          <table className="table table-hover">
            <thead><tr><th>Date</th><th>Booking</th><th>Customer</th><th>Hotel</th><th>Method</th><th>Transaction</th><th className="text-end">Amount</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {data.payments.map((p) => (
                <tr key={p._id}>
                  <td>{fmtDate(p.createdAt)}</td><td>{p.booking?.bookingId || '-'}</td>
                  <td>{p.user?.name}<div className="small text-muted">{p.user?.email}</div></td><td>{p.booking?.hotel?.name || '-'}</td>
                  <td className="text-capitalize">{p.method}{p.method === 'simulated' ? ' (demo)' : ''}</td><td className="small text-break">{p.transactionId || '-'}</td>
                  <td className="text-end fw-semibold">{inr(p.amount)}</td><td><StatusBadge status={p.status} /></td>
                  <td>{p.status === 'successful' && <button className="btn btn-sm btn-outline-danger" onClick={() => setRefund(p)}>Refund</button>}</td>
                </tr>
              ))}
              {!data.payments.length && <tr><td colSpan="9" className="text-center text-muted py-4">No payments found.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} pages={data.pages} onChange={setPage} />
      <ConfirmModal show={!!refund} danger busy={busy} title="Refund this payment?" confirmText="Refund and cancel booking"
        message={refund ? `${inr(refund.amount)} will be refunded and booking ${refund.booking?.bookingId} cancelled.` : ''} onConfirm={doRefund} onCancel={() => setRefund(null)} />
    </>
  );
}
