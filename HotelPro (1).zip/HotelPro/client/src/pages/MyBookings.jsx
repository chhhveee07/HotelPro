import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { bookingService, errMsg } from '../services/api-helpers';
import { useToast } from '../context/ToastContext';
import Loader from '../components/Loader';
import StatusBadge from '../components/StatusBadge';
import ConfirmModal from '../components/ConfirmModal';
import Img from '../components/ImageWithFallback';
import { fmtDate, inr } from '../utils';

const TABS = ['all', 'pending', 'confirmed', 'completed', 'cancelled'];

export default function MyBookings() {
  const toast = useToast();
  const [bookings, setBookings] = useState([]);
  const [tab, setTab] = useState('all');
  const [loading, setLoading] = useState(true);
  const [toCancel, setToCancel] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = () => bookingService.mine().then((d) => setBookings(d.bookings)).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const cancel = async () => {
    setBusy(true);
    try { const d = await bookingService.cancel(toCancel._id); toast.success(d.message); setToCancel(null); await load(); }
    catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };

  const shown = tab === 'all' ? bookings : bookings.filter((b) => b.status === tab);

  return (
    <>
      <div className="hp-page-head"><div className="container"><h1>My bookings</h1></div></div>
      <div className="container py-4">
        <div className="d-flex flex-wrap gap-2 mb-4">
          {TABS.map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`btn btn-sm text-capitalize ${tab === t ? 'btn-hp' : 'btn-outline-secondary'}`}>
              {t} {t === 'all' ? `(${bookings.length})` : `(${bookings.filter((b) => b.status === t).length})`}
            </button>
          ))}
        </div>
        {loading ? <Loader /> : shown.length === 0 ? (
          <div className="hp-empty hp-panel"><h5>Nothing here yet</h5><p>No {tab === 'all' ? '' : tab} bookings to show.</p><Link to="/hotels" className="btn btn-hp">Find a hotel</Link></div>
        ) : (
          <div className="d-flex flex-column gap-3">
            {shown.map((b) => {
              const canCancel = ['pending', 'confirmed'].includes(b.status) && new Date(b.checkIn) >= new Date(new Date().toDateString());
              return (
                <div className="hp-room" key={b._id}>
                  <Img src={b.room?.images?.[0] || b.hotel?.images?.[0]} alt={b.hotel?.name} />
                  <div className="flex-grow-1">
                    <div className="d-flex justify-content-between flex-wrap gap-2">
                      <div><h5 className="mb-0">{b.hotel?.name}</h5><small className="text-muted">{b.room?.name} · {b.hotel?.city}</small></div>
                      <div className="d-flex gap-2 align-items-start"><StatusBadge status={b.status} /><StatusBadge status={b.paymentStatus} /></div>
                    </div>
                    <div className="small my-2">ID <strong>{b.bookingId}</strong> · {fmtDate(b.checkIn)} to {fmtDate(b.checkOut)} · {b.nights} night(s) · {b.guests} guest(s)</div>
                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">
                      <strong className="hp-price">{inr(b.totalPrice)}</strong>
                      <div className="d-flex gap-2">
                        <Link className="btn btn-outline-hp btn-sm" to={`/bookings/${b._id}`}>Details</Link>
                        {b.status === 'pending' && <Link className="btn btn-gold btn-sm" to={`/bookings/${b._id}?pay=1`}>Pay now</Link>}
                        {canCancel && <button className="btn btn-outline-danger btn-sm" onClick={() => setToCancel(b)}>Cancel</button>}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      <ConfirmModal show={!!toCancel} danger busy={busy} title="Cancel this booking?" confirmText="Yes, cancel booking"
        message={toCancel ? `Booking ${toCancel.bookingId} will be cancelled${toCancel.paymentStatus === 'successful' ? ' and your payment refunded' : ''}.` : ''}
        onConfirm={cancel} onCancel={() => setToCancel(null)} />
    </>
  );
}
