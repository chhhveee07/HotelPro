import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { bookingService, errMsg } from '../services/api-helpers';
import { useToast } from '../context/ToastContext';
import Loader from '../components/Loader';
import StatusBadge from '../components/StatusBadge';
import Pagination from '../components/Pagination';
import ConfirmModal from '../components/ConfirmModal';
import { fmtDate, inr } from '../utils';

export default function ManageBookings() {
  const toast = useToast();
  const [data, setData] = useState({ bookings: [], total: 0, pages: 1 });
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [cancelTarget, setCancelTarget] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = () => bookingService.adminAll({ status, search, page, limit: 15 }).then(setData).catch((e) => toast.error(errMsg(e))).finally(() => setLoading(false));
  useEffect(() => { setLoading(true); load(); /* eslint-disable-next-line */ }, [status, page]);

  const changeStatus = async (b, next) => {
    if (next === 'cancelled') return setCancelTarget(b);
    try { await bookingService.setStatus(b._id, next); toast.success(`Booking ${b.bookingId} marked ${next}`); load(); }
    catch (e) { toast.error(errMsg(e)); }
  };
  const doCancel = async () => {
    setBusy(true);
    try { await bookingService.setStatus(cancelTarget._id, 'cancelled'); toast.success('Booking cancelled'); load(); }
    catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); setCancelTarget(null); }
  };

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div><h2 className="mb-0">Reservations</h2><p className="text-muted mb-0">{data.total} booking(s)</p></div>
        <form className="d-flex gap-2" onSubmit={(e) => { e.preventDefault(); setPage(1); setLoading(true); load(); }}>
          <input className="form-control" placeholder="Search booking ID" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search booking ID" />
          <select className="form-select" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} aria-label="Filter by status">
            <option value="">All statuses</option>{['pending', 'confirmed', 'completed', 'cancelled'].map((s) => <option key={s}>{s}</option>)}
          </select>
          <button className="btn btn-hp">Search</button>
        </form>
      </div>
      {loading ? <Loader /> : (
        <div className="hp-table table-responsive">
          <table className="table table-hover">
            <thead><tr><th>Booking ID</th><th>Guest</th><th>Hotel / Room</th><th>Stay</th><th>Guests</th><th className="text-end">Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {data.bookings.map((b) => (
                <tr key={b._id}>
                  <td><Link to={`/bookings/${b._id}`}><strong>{b.bookingId}</strong></Link></td>
                  <td>{b.user?.name}<div className="small text-muted">{b.user?.email}</div></td>
                  <td>{b.hotel?.name}<div className="small text-muted">{b.room?.name}</div></td>
                  <td className="text-nowrap">{fmtDate(b.checkIn)} to {fmtDate(b.checkOut)}<div className="small text-muted">{b.nights} night(s)</div></td>
                  <td>{b.guests}</td><td className="text-end">{inr(b.totalPrice)}</td>
                  <td><StatusBadge status={b.paymentStatus} /></td><td><StatusBadge status={b.status} /></td>
                  <td>
                    {b.status !== 'cancelled' && (
                      <select className="form-select form-select-sm" value="" onChange={(e) => e.target.value && changeStatus(b, e.target.value)} aria-label={`Change status for ${b.bookingId}`}>
                        <option value="">Update…</option>
                        {['pending', 'confirmed', 'completed', 'cancelled'].filter((s) => s !== b.status).map((s) => <option key={s} value={s}>Mark {s}</option>)}
                      </select>
                    )}
                  </td>
                </tr>
              ))}
              {!data.bookings.length && <tr><td colSpan="9" className="text-center text-muted py-4">No bookings found.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} pages={data.pages} onChange={setPage} />
      <ConfirmModal show={!!cancelTarget} danger busy={busy} title="Cancel this reservation?" confirmText="Cancel reservation"
        message={cancelTarget ? `${cancelTarget.bookingId} will be cancelled${cancelTarget.paymentStatus === 'successful' ? ' and the payment refunded' : ''}.` : ''}
        onConfirm={doCancel} onCancel={() => setCancelTarget(null)} />
    </>
  );
}
