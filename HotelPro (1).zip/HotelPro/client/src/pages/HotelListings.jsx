import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import SearchBar from '../components/SearchBar';
import HotelCard from '../components/HotelCard';
import Loader from '../components/Loader';
import Pagination from '../components/Pagination';
import { hotelService, errMsg } from '../services/api-helpers';

export default function HotelListings() {
  const [params, setParams] = useSearchParams();
  const [data, setData] = useState({ hotels: [], total: 0, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [price, setPrice] = useState({ min: params.get('minPrice') || '', max: params.get('maxPrice') || '' });

  const page = Number(params.get('page')) || 1;
  const get = (k) => params.get(k) || '';

  useEffect(() => {
    setLoading(true);
    setError('');
    const q = Object.fromEntries(params.entries());
    hotelService.list({ ...q, limit: 9 })
      .then(setData)
      .catch((e) => setError(errMsg(e)))
      .finally(() => setLoading(false));
  }, [params]);

  const update = (patch) => {
    const next = new URLSearchParams(params);
    Object.entries(patch).forEach(([k, v]) => (v === '' || v === undefined ? next.delete(k) : next.set(k, v)));
    if (!('page' in patch)) next.delete('page');
    setParams(next);
  };

  const applyPrice = (e) => { e.preventDefault(); update({ minPrice: price.min, maxPrice: price.max }); };
  const clear = () => { setPrice({ min: '', max: '' }); setParams({}); };

  // Carry dates to the details page so availability is shown there too
  const carry = ['checkIn', 'checkOut', 'guests'].filter((k) => get(k)).map((k) => `${k}=${get(k)}`).join('&');

  return (
    <>
      <div className="hp-page-head">
        <div className="container">
          <h1 className="mb-3">Find your hotel</h1>
          <SearchBar compact initial={{ search: get('search'), checkIn: get('checkIn'), checkOut: get('checkOut'), guests: get('guests') || 2 }} key={params.toString()} />
        </div>
      </div>

      <div className="container py-4">
        <div className="row g-4">
          <aside className="col-lg-3">
            <div className="hp-panel">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="mb-0">Filters</h5>
                <button className="btn btn-link btn-sm p-0" onClick={clear}>Clear all</button>
              </div>
              <form onSubmit={applyPrice} className="mb-3">
                <label className="form-label">Price per night (₹)</label>
                <div className="d-flex gap-2 mb-2">
                  <input type="number" min="0" className="form-control" placeholder="Min" value={price.min} onChange={(e) => setPrice({ ...price, min: e.target.value })} aria-label="Minimum price" />
                  <input type="number" min="0" className="form-control" placeholder="Max" value={price.max} onChange={(e) => setPrice({ ...price, max: e.target.value })} aria-label="Maximum price" />
                </div>
                <button className="btn btn-hp btn-sm w-100">Apply price</button>
              </form>
              <div className="mb-3">
                <label className="form-label" htmlFor="f-rating">Guest rating</label>
                <select id="f-rating" className="form-select" value={get('rating')} onChange={(e) => update({ rating: e.target.value })}>
                  <option value="">Any rating</option>
                  <option value="4.5">4.5 and above</option>
                  <option value="4">4.0 and above</option>
                  <option value="3.5">3.5 and above</option>
                </select>
              </div>
              <div>
                <label className="form-label" htmlFor="f-sort">Sort by</label>
                <select id="f-sort" className="form-select" value={get('sort')} onChange={(e) => update({ sort: e.target.value })}>
                  <option value="">Recommended</option>
                  <option value="price_asc">Price: low to high</option>
                  <option value="price_desc">Price: high to low</option>
                  <option value="rating">Top rated</option>
                  <option value="newest">Newest</option>
                </select>
              </div>
            </div>
          </aside>

          <section className="col-lg-9">
            <p className="text-muted">{loading ? 'Searching…' : `${data.total} hotel${data.total === 1 ? '' : 's'} found`}{get('checkIn') && ' with rooms free for your dates'}</p>
            {error && <div className="alert alert-danger">{error}</div>}
            {loading ? <Loader /> : data.hotels.length === 0 ? (
              <div className="hp-empty hp-panel">
                <h5>No hotels match these filters</h5>
                <p>Try a different city, a wider price range or other dates.</p>
                <button className="btn btn-hp" onClick={clear}>Reset filters</button>
              </div>
            ) : (
              <>
                <div className="row g-4">
                  {data.hotels.map((h) => <div className="col-md-6 col-xl-4" key={h._id}><HotelCard hotel={h} query={carry ? `?${carry}` : ''} /></div>)}
                </div>
                <Pagination page={page} pages={data.pages} onChange={(p) => update({ page: p })} />
              </>
            )}
          </section>
        </div>
      </div>
    </>
  );
}
