import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { userService, errMsg } from '../services/api-helpers';

export default function MyProfile() {
  const { user, setUser } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ name: user.name, email: user.email, phone: user.phone || '', address: user.address || '' });
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [busy, setBusy] = useState(false);

  const saveProfile = async (e) => {
    e.preventDefault(); setBusy(true);
    try { const d = await userService.updateProfile(form); setUser(d.user); toast.success('Profile updated'); }
    catch (err) { toast.error(errMsg(err)); } finally { setBusy(false); }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    if (pw.newPassword !== pw.confirm) return toast.error('New passwords do not match');
    setBusy(true);
    try { await userService.changePassword({ currentPassword: pw.currentPassword, newPassword: pw.newPassword }); toast.success('Password changed'); setPw({ currentPassword: '', newPassword: '', confirm: '' }); }
    catch (err) { toast.error(errMsg(err)); } finally { setBusy(false); }
  };

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <>
      <div className="hp-page-head"><div className="container"><h1>My profile</h1></div></div>
      <div className="container py-4">
        <div className="row g-4">
          <div className="col-lg-7">
            <form className="hp-panel" onSubmit={saveProfile}>
              <h5>Personal details</h5>
              <div className="row g-3">
                <div className="col-md-6"><label className="form-label" htmlFor="p-name">Full name</label><input id="p-name" className="form-control" required minLength={2} value={form.name} onChange={set('name')} /></div>
                <div className="col-md-6"><label className="form-label" htmlFor="p-email">Email</label><input id="p-email" type="email" className="form-control" required value={form.email} onChange={set('email')} /></div>
                <div className="col-md-6"><label className="form-label" htmlFor="p-phone">Phone</label><input id="p-phone" className="form-control" pattern="[0-9+\- ]{7,15}" value={form.phone} onChange={set('phone')} /></div>
                <div className="col-12"><label className="form-label" htmlFor="p-addr">Address</label><textarea id="p-addr" rows="2" className="form-control" maxLength={250} value={form.address} onChange={set('address')} /></div>
              </div>
              <button className="btn btn-hp mt-3" disabled={busy}>Save changes</button>
            </form>
          </div>
          <div className="col-lg-5">
            <form className="hp-panel" onSubmit={savePassword}>
              <h5>Change password</h5>
              <div className="mb-3"><label className="form-label" htmlFor="pw-c">Current password</label><input id="pw-c" type="password" className="form-control" required value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} /></div>
              <div className="mb-3"><label className="form-label" htmlFor="pw-n">New password</label><input id="pw-n" type="password" className="form-control" required minLength={6} value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} /></div>
              <div className="mb-3"><label className="form-label" htmlFor="pw-r">Confirm new password</label><input id="pw-r" type="password" className="form-control" required minLength={6} value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} /></div>
              <button className="btn btn-outline-hp" disabled={busy}>Update password</button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
