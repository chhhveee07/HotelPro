import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { bookingService, errMsg } from '../services/api-helpers';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Loader from '../components/Loader';
import StatusBadge from '../components/StatusBadge';
import PaymentModal from '../components/PaymentModal';
import ConfirmModal from '../components/ConfirmModal';
import { fmtDate, inr } from '../utils';

export default function BookingDetails() {
  const { id } = useParams();
  const [params, setParams] = useSearchParams();
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [pay, setPay] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = () => bookingService.get(id).then(setData).catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [id]);

  // Arriving from the booking form (?pay=1) opens payment straight away
  useEffect(() => {
    if (data && params.get('pay') === '1' && data.booking.status === 'pending') setPay(true);
  }, [data, params]);

  const closePay = () => { setPay(false); const n = new URLSearchParams(params); n.delete('pay'); setParams(n, { replace: true }); };
  const paid = (msg, ok) => { closePay(); ok ? toast.success(msg) : toast.error(msg); load(); };

  const cancel = async () => {
    setBusy(true);
    try { const d = await bookingService.cancel(data.booking._id); toast.success(d.message); setCancelOpen(false); load(); }
    catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };

  if (error) return <div className="container py-5"><div className="alert alert-danger">{error}</div><Link to="/my-bookings">Back to my bookings</Link></div>;
  if (!data) return <Loader full />;
  const { booking: b, payment } = data;
  const canCancel = ['pending', 'confirmed'].includes(b.status);

  return (
    <>
      <div className="hp-page-head">
        <div className="container d-flex flex-wrap justify-content-between align-items-center gap-2">
          <div><small className="text-muted">Booking ID</small><h1>{b.bookingId}</h1></div>
          <div className="d-flex gap-2"><StatusBadge status={b.status} /><StatusBadge status={b.paymentStatus} /></div>
        </div>
      </div>
      <div className="container py-4">
        {b.status === 'confirmed' && <div className="alert alert-success">Your booking is confirmed. Show booking ID <strong>{b.bookingId}</strong> at check-in.</div>}
        {b.status === 'pending' && <div className="alert alert-warning d-flex justify-content-between align-items-center flex-wrap gap-2">
          <span>Payment is pending. Your room is held but not yet confirmed.</span>
          <button className="btn btn-gold btn-sm" onClick={() => setPay(true)}>Pay {inr(b.totalPrice)}</button></div>}
        <div className="row g-4">
          <div className="col-lg-7">
            <div className="hp-panel">
              <h5>Stay details</h5>
              <dl className="row mb-0">
                <dt className="col-sm-4">Hotel</dt><dd className="col-sm-8"><Link to={`/hotels/${b.hotel?._id}`}>{b.hotel?.name}</Link><br /><small className="text-muted">{b.hotel?.address}</small></dd>
                <dt className="col-sm-4">Room</dt><dd className="col-sm-8">{b.room?.name} ({b.room?.category})</dd>
                <dt className="col-sm-4">Check-in</dt><dd className="col-sm-8">{fmtDate(b.checkIn)} from {b.hotel?.policies?.checkInTime}</dd>
                <dt className="col-sm-4">Check-out</dt><dd className="col-sm-8">{fmtDate(b.checkOut)} by {b.hotel?.policies?.checkOutTime}</dd>
                <dt className="col-sm-4">Guests</dt><dd className="col-sm-8">{b.guests} · {b.nights} night(s)</dd>
                <dt className="col-sm-4">Guest name</dt><dd className="col-sm-8">{b.guestName}{b.guestPhone ? ` · ${b.guestPhone}` : ''}</dd>
                {b.specialRequests && <><dt className="col-sm-4">Requests</dt><dd className="col-sm-8">{b.specialRequests}</dd></>}
                <dt className="col-sm-4">Booked on</dt><dd className="col-sm-8">{fmtDate(b.createdAt)}</dd>
                {b.cancelledAt && <><dt className="col-sm-4">Cancelled on</dt><dd className="col-sm-8">{fmtDate(b.cancelledAt)}</dd></>}
              </dl>
            </div>
          </div>
          <div className="col-lg-5">
            <div className="hp-panel mb-3">
              <h5>Price summary</h5>
              <div className="d-flex justify-content-between"><span>{inr(b.pricePerNight)} × {b.nights} night(s)</span><span>{inr(b.totalPrice)}</span></div>
              <hr /><div className="d-flex justify-content-between fs-5"><strong>Total</strong><strong>{inr(b.totalPrice)}</strong></div>
            </div>
            <div className="hp-panel mb-3">
              <h5>Payment</h5>
              {payment ? (
                <dl className="row mb-0 small">
                  <dt className="col-5">Status</dt><dd className="col-7"><StatusBadge status={payment.status} /></dd>
                  <dt className="col-5">Method</dt><dd className="col-7 text-capitalize">{payment.method}{payment.method === 'simulated' ? ' (demo)' : ''}</dd>
                  {payment.transactionId && <><dt className="col-5">Transaction</dt><dd className="col-7 text-break">{payment.transactionId}</dd></>}
                  {payment.paidAt && <><dt className="col-5">Paid on</dt><dd className="col-7">{fmtDate(payment.paidAt)}</dd></>}
                </dl>
              ) : <p className="text-muted mb-0">No payment started yet.</p>}
            </div>
            <div className="d-grid gap-2">
              {canCancel && <button className="btn btn-outline-danger" onClick={() => setCancelOpen(true)}>Cancel booking</button>}
              <button className="btn btn-outline-hp" onClick={() => navigate(user.role === 'admin' ? '/admin/bookings' : '/my-bookings')}>Back to bookings</button>
            </div>
          </div>
        </div>
      </div>
      <PaymentModal show={pay} booking={b} user={user} onClose={closePay} onDone={paid} />
      <ConfirmModal show={cancelOpen} danger busy={busy} title="Cancel this booking?" confirmText="Yes, cancel"
        message={b.paymentStatus === 'successful' ? 'Your payment will be refunded.' : 'This frees the room for other guests.'}
        onConfirm={cancel} onCancel={() => setCancelOpen(false)} />
    </>
  );
}
