import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import SearchBar from '../components/SearchBar';
import HotelCard from '../components/HotelCard';
import Img from '../components/ImageWithFallback';
import Loader from '../components/Loader';
import { hotelService } from '../services';
import { inr } from '../utils';

const offers = [
  { title: 'Early planner: 15% off', text: 'Book 30 days ahead on any stay of two nights or more.', code: 'PLAN15' },
  { title: 'Weekend escape', text: 'Complimentary breakfast on Friday to Sunday stays at select resorts.', code: 'WEEKEND', alt: true },
  { title: 'Long stay savings', text: 'Stay five nights or more and get one late check-out free.', code: 'STAY5' },
];

const reviews = [
  { name: 'Ananya Rao', city: 'Bengaluru', text: 'Booking took under two minutes and the room matched the photos. The booking ID made check-in effortless.' },
  { name: 'Karan Malhotra', city: 'Delhi', text: 'I like that I could see exactly which rooms were free for my dates before choosing. No surprises at the desk.' },
  { name: 'Meera Nair', city: 'Kochi', text: 'Cancelling a plan change was one click and my refund showed up in the payment history straight away.' },
];

export default function Home() {
  const [destinations, setDestinations] = useState([]);
  const [featured, setFeatured] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([hotelService.destinations(), hotelService.list({ featured: true, limit: 6 }), hotelService.list({ limit: 1 })])
      .then(([d, f, all]) => { setDestinations(d.destinations); setFeatured(f.hotels); setTotal(all.total); })
      .catch(() => setError('Could not load hotels. Make sure the backend is running and the database is seeded.'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <>
      <section className="hp-hero">
        <div className="container">
          <h1>Stay somewhere worth the trip.</h1>
          <p className="mt-3">Compare hotels across India, see which rooms are free for your dates and book with a confirmation ID you can use at the front desk.</p>
          <div className="hp-hero-stats">
            <div><strong>{total || '8'}+</strong><span>hotels listed</span></div>
            <div><strong>{destinations.length || '8'}</strong><span>destinations</span></div>
            <div><strong>24/7</strong><span>booking access</span></div>
          </div>
        </div>
      </section>

      <div className="container hp-search-wrap"><SearchBar /></div>

      {error && <div className="container mt-4"><div className="alert alert-warning">{error}</div></div>}

      <section className="hp-section">
        <div className="container">
          <div className="hp-section-head">
            <div><h2>Popular destinations</h2><p>Cities our guests book most</p></div>
            <Link to="/hotels" className="btn btn-outline-hp btn-sm">Browse all hotels</Link>
          </div>
          {loading ? <Loader /> : (
            <div className="row g-3">
              {destinations.map((d) => (
                <div className="col-6 col-md-4 col-lg-3" key={d.city}>
                  <Link to={`/hotels?search=${encodeURIComponent(d.city)}`} className="hp-dest">
                    <Img src={d.image} alt={d.city} />
                    <div><h5>{d.city}</h5><small>{d.count} hotel{d.count > 1 ? 's' : ''} from {inr(d.minPrice)}</small></div>
                  </Link>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="hp-section bg-beige">
        <div className="container">
          <div className="hp-section-head"><div><h2>Featured hotels</h2><p>Hand-picked stays with top guest ratings</p></div></div>
          {loading ? <Loader /> : (
            <div className="row g-4">
              {featured.map((h) => <div className="col-md-6 col-lg-4" key={h._id}><HotelCard hotel={h} /></div>)}
            </div>
          )}
        </div>
      </section>

      <section className="hp-section">
        <div className="container">
          <div className="hp-section-head"><div><h2>Special offers</h2><p>Sample promotions shown for demonstration</p></div></div>
          <div className="row g-4">
            {offers.map((o) => (
              <div className="col-md-4" key={o.code}>
                <div className={`hp-offer ${o.alt ? 'alt' : ''}`}>
                  <h4>{o.title}</h4>
                  <p className="opacity-75">{o.text}</p>
                  <span className="code">{o.code}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="hp-section bg-beige">
        <div className="container">
          <div className="hp-section-head"><div><h2>What guests say</h2></div></div>
          <div className="row g-4">
            {reviews.map((r) => (
              <div className="col-md-4" key={r.name}>
                <div className="hp-quote">
                  <p>“{r.text}”</p>
                  <div className="d-flex align-items-center gap-2 mt-3">
                    <div className="hp-avatar">{r.name[0]}</div>
                    <div><strong className="d-block">{r.name}</strong><small className="text-muted">{r.city}</small></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
