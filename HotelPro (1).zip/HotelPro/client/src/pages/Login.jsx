import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { errMsg } from '../services/api';

export default function Login() {
  const { login } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      const user = await login(form);
      toast.success(`Welcome back, ${user.name.split(' ')[0]}`);
      navigate(user.role === 'admin' ? '/admin' : location.state?.from || '/dashboard', { replace: true });
    } catch (err) { setError(errMsg(err)); } finally { setBusy(false); }
  };

  return (
    <div className="hp-auth">
      <form className="hp-auth-card" onSubmit={submit}>
        <h2 className="h3">Log in</h2>
        <p className="text-muted">Access your bookings and profile.</p>
        {error && <div className="alert alert-danger py-2">{error}</div>}
        <div className="mb-3"><label className="form-label" htmlFor="email">Email</label>
          <input id="email" type="email" className="form-control" required autoComplete="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
        <div className="mb-4"><label className="form-label" htmlFor="password">Password</label>
          <input id="password" type="password" className="form-control" required autoComplete="current-password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
        <button className="btn btn-hp w-100" disabled={busy}>{busy ? 'Logging in…' : 'Log in'}</button>
        <p className="text-center small mt-3 mb-1">New to HotelPro? <Link to="/register">Create an account</Link></p>
        <p className="text-center small mb-0"><Link to="/admin/login">Administrator? Sign in here</Link></p>
      </form>
    </div>
  );
}
