import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="container py-5 text-center">
      <h1 style={{ fontSize: '5rem' }}>404</h1>
      <h4>This page does not exist</h4>
      <p className="text-muted">The link may be broken or the page was moved.</p>
      <Link to="/" className="btn btn-hp me-2">Go home</Link>
      <Link to="/hotels" className="btn btn-outline-hp">Browse hotels</Link>
    </div>
  );
}
