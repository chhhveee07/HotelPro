import { useEffect, useState } from 'react';
import { hotelService, roomService, errMsg } from '../services/api-helpers';
import { useToast } from '../context/ToastContext';
import Loader from '../components/Loader';
import Modal from '../components/Modal';
import ConfirmModal from '../components/ConfirmModal';
import Img from '../components/ImageWithFallback';
import { inr } from '../utils';

const CATS = ['Standard', 'Deluxe', 'Suite', 'Executive', 'Family', 'Presidential'];
const EMPTY = { hotel: '', name: '', category: 'Standard', pricePerNight: '', capacity: 2, quantity: 1, bedType: 'Queen', sizeSqFt: '', description: '', amenities: '', images: '', isActive: true };

export default function ManageRooms() {
  const toast = useToast();
  const [hotels, setHotels] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [hotelFilter, setHotelFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const [editing, setEditing] = useState(null);
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [del, setDel] = useState(null);
  const [priceEdit, setPriceEdit] = useState({}); // roomId -> draft price

  const load = () => roomService.all(hotelFilter ? { hotel: hotelFilter } : {}).then((d) => setRooms(d.rooms)).finally(() => setLoading(false));
  useEffect(() => { hotelService.adminAll().then((d) => setHotels(d.hotels)); }, []);
  useEffect(() => { setLoading(true); load(); /* eslint-disable-next-line */ }, [hotelFilter]);

  const openNew = () => { setEditing(null); setForm({ ...EMPTY, hotel: hotelFilter || hotels[0]?._id || '' }); setFiles([]); setErr(''); };
  const openEdit = (r) => { setEditing(r); setFiles([]); setErr(''); setForm({ ...r, hotel: r.hotel?._id, amenities: (r.amenities || []).join(', '), images: (r.images || []).join('\n') }); };
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const save = async (e) => {
    e.preventDefault(); setBusy(true); setErr('');
    const body = {
      hotel: form.hotel, name: form.name, category: form.category, description: form.description, bedType: form.bedType,
      pricePerNight: Number(form.pricePerNight), capacity: Number(form.capacity), quantity: Number(form.quantity),
      ...(form.sizeSqFt !== '' && form.sizeSqFt != null ? { sizeSqFt: Number(form.sizeSqFt) } : {}), isActive: form.isActive,
      amenities: form.amenities.split(',').map((s) => s.trim()).filter(Boolean),
      images: form.images.split(/[\n,]/).map((s) => s.trim()).filter(Boolean),
    };
    try {
      const d = editing ? await roomService.update(editing._id, body) : await roomService.create(body);
      if (files.length) await roomService.uploadImages(d.room._id, files);
      toast.success(editing ? 'Room updated' : 'Room added'); setForm(null); load();
    } catch (er) { setErr(errMsg(er)); } finally { setBusy(false); }
  };

  const savePrice = async (r) => {
    try { await roomService.updatePrice(r._id, Number(priceEdit[r._id])); toast.success('Price updated'); setPriceEdit((p) => { const n = { ...p }; delete n[r._id]; return n; }); load(); }
    catch (er) { toast.error(errMsg(er)); }
  };

  const remove = async () => {
    setBusy(true);
    try { await roomService.remove(del._id); toast.success('Room deleted'); load(); } catch (er) { toast.error(errMsg(er)); }
    finally { setDel(null); setBusy(false); }
  };

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div><h2 className="mb-0">Rooms</h2><p className="text-muted mb-0">Manage room types, prices and inventory.</p></div>
        <div className="d-flex gap-2">
          <select className="form-select" aria-label="Filter by hotel" value={hotelFilter} onChange={(e) => setHotelFilter(e.target.value)}>
            <option value="">All hotels</option>{hotels.map((h) => <option key={h._id} value={h._id}>{h.name}</option>)}
          </select>
          <button className="btn btn-gold text-nowrap" onClick={openNew} disabled={!hotels.length}>Add room</button>
        </div>
      </div>
      {loading ? <Loader /> : (
        <div className="hp-table table-responsive">
          <table className="table table-hover">
            <thead><tr><th></th><th>Room</th><th>Hotel</th><th>Category</th><th>Sleeps</th><th>Units</th><th>Price / night</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {rooms.map((r) => (
                <tr key={r._id}>
                  <td><Img className="thumb" src={r.images?.[0]} alt="" /></td>
                  <td><strong>{r.name}</strong></td><td>{r.hotel?.name}</td><td>{r.category}</td><td>{r.capacity}</td><td>{r.quantity}</td>
                  <td style={{ minWidth: 150 }}>
                    {priceEdit[r._id] !== undefined ? (
                      <div className="input-group input-group-sm">
                        <input type="number" min="1" className="form-control" value={priceEdit[r._id]} onChange={(e) => setPriceEdit({ ...priceEdit, [r._id]: e.target.value })} aria-label="New price" />
                        <button className="btn btn-hp" onClick={() => savePrice(r)}>Save</button>
                      </div>
                    ) : <button className="btn btn-link p-0 text-decoration-none" title="Click to change price" onClick={() => setPriceEdit({ ...priceEdit, [r._id]: r.pricePerNight })}>{inr(r.pricePerNight)} ✎</button>}
                  </td>
                  <td><span className={`hp-badge ${r.isActive ? 'hp-badge-success' : 'hp-badge-secondary'}`}>{r.isActive ? 'active' : 'hidden'}</span></td>
                  <td className="text-end text-nowrap">
                    <button className="btn btn-sm btn-outline-hp me-1" onClick={() => openEdit(r)}>Edit</button>
                    <button className="btn btn-sm btn-outline-danger" onClick={() => setDel(r)}>Delete</button>
                  </td>
                </tr>
              ))}
              {!rooms.length && <tr><td colSpan="9" className="text-center text-muted py-4">No rooms found.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      <Modal show={!!form} size="lg" onClose={() => !busy && setForm(null)} title={editing ? `Edit ${editing.name}` : 'Add room'}>
        {form && (
          <form onSubmit={save}>
            {err && <div className="alert alert-danger py-2">{err}</div>}
            <div className="row g-3">
              <div className="col-md-6"><label className="form-label">Hotel</label><select className="form-select" required value={form.hotel} onChange={set('hotel')}>{hotels.map((h) => <option key={h._id} value={h._id}>{h.name}</option>)}</select></div>
              <div className="col-md-6"><label className="form-label">Room name</label><input className="form-control" required value={form.name} onChange={set('name')} /></div>
              <div className="col-md-4"><label className="form-label">Category</label><select className="form-select" value={form.category} onChange={set('category')}>{CATS.map((c) => <option key={c}>{c}</option>)}</select></div>
              <div className="col-md-4"><label className="form-label">Price per night (₹)</label><input type="number" min="1" className="form-control" required value={form.pricePerNight} onChange={set('pricePerNight')} /></div>
              <div className="col-md-4"><label className="form-label">Bed type</label><input className="form-control" value={form.bedType || ''} onChange={set('bedType')} /></div>
              <div className="col-md-4"><label className="form-label">Max guests</label><input type="number" min="1" max="10" className="form-control" required value={form.capacity} onChange={set('capacity')} /></div>
              <div className="col-md-4"><label className="form-label">Rooms of this type</label><input type="number" min="1" className="form-control" required value={form.quantity} onChange={set('quantity')} /></div>
              <div className="col-md-4"><label className="form-label">Size (sq ft)</label><input type="number" min="0" className="form-control" value={form.sizeSqFt ?? ''} onChange={set('sizeSqFt')} /></div>
              <div className="col-12"><label className="form-label">Description</label><textarea className="form-control" rows="2" value={form.description || ''} onChange={set('description')} /></div>
              <div className="col-12"><label className="form-label">Amenities (comma separated)</label><input className="form-control" value={form.amenities} onChange={set('amenities')} /></div>
              <div className="col-12"><label className="form-label">Image URLs (one per line)</label><textarea className="form-control" rows="2" value={form.images} onChange={set('images')} /></div>
              <div className="col-12"><label className="form-label">Upload images</label><input type="file" multiple accept="image/*" className="form-control" onChange={(e) => setFiles(e.target.files)} /></div>
              <div className="col-12"><div className="form-check"><input id="r-a" type="checkbox" className="form-check-input" checked={!!form.isActive} onChange={set('isActive')} /><label htmlFor="r-a" className="form-check-label">Bookable</label></div></div>
            </div>
            <div className="d-flex justify-content-end gap-2 mt-4">
              <button type="button" className="btn btn-outline-secondary" onClick={() => setForm(null)} disabled={busy}>Cancel</button>
              <button className="btn btn-hp" disabled={busy}>{busy ? 'Saving…' : 'Save room'}</button>
            </div>
          </form>
        )}
      </Modal>
      <ConfirmModal show={!!del} danger busy={busy} title="Delete this room?" confirmText="Delete room"
        message={del ? `${del.name} will be removed. Rooms with upcoming bookings cannot be deleted.` : ''} onConfirm={remove} onCancel={() => setDel(null)} />
    </>
  );
}
