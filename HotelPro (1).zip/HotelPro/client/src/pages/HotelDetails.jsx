import { useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { hotelService, bookingService, errMsg } from '../services/api-helpers';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Img from '../components/ImageWithFallback';
import Loader from '../components/Loader';
import Modal from '../components/Modal';
import StarRating, { Stars } from '../components/StarRating';
import { dateInput, inr, nightsBetween } from '../utils';

export default function HotelDetails() {
  const { id } = useParams();
  const [params, setParams] = useSearchParams();
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const [hotel, setHotel] = useState(null);
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [checkIn, setCheckIn] = useState(params.get('checkIn') || dateInput(1));
  const [checkOut, setCheckOut] = useState(params.get('checkOut') || dateInput(3));
  const [guests, setGuests] = useState(Number(params.get('guests')) || 2);

  const [selected, setSelected] = useState(null); // room being booked
  const [form, setForm] = useState({ guestName: '', guestPhone: '', specialRequests: '' });
  const [busy, setBusy] = useState(false);
  const [formErr, setFormErr] = useState('');

  const nights = nightsBetween(checkIn, checkOut);
  const datesOk = nights >= 1 && nights <= 30;

  // Reload hotel + room availability whenever the dates change
  useEffect(() => {
    if (!datesOk) return;
    setLoading(true);
    hotelService.get(id, { checkIn, checkOut })
      .then((d) => { setHotel(d.hotel); setRooms(d.rooms); setError(''); })
      .catch((e) => setError(errMsg(e)))
      .finally(() => setLoading(false));
  }, [id, checkIn, checkOut, datesOk]);

  useEffect(() => {
    const next = new URLSearchParams(params);
    next.set('checkIn', checkIn); next.set('checkOut', checkOut); next.set('guests', guests);
    setParams(next, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [checkIn, checkOut, guests]);

  const total = useMemo(() => (selected ? selected.pricePerNight * nights : 0), [selected, nights]);

  const openBooking = (room) => {
    if (!user) {
      toast.info('Please log in to book a room');
      return navigate('/login', { state: { from: location.pathname + location.search } });
    }
    if (user.role === 'admin') return toast.error('Admin accounts cannot make bookings. Use a customer account.');
    setForm({ guestName: user.name, guestPhone: user.phone || '', specialRequests: '' });
    setFormErr('');
    setSelected(room);
  };

  const confirm = async (e) => {
    e.preventDefault();
    setBusy(true); setFormErr('');
    try {
      const { booking } = await bookingService.create({ roomId: selected._id, checkIn, checkOut, guests, ...form });
      toast.success(`Booking ${booking.bookingId} created. Complete payment to confirm.`);
      navigate(`/bookings/${booking._id}?pay=1`);
    } catch (err) {
      setFormErr(errMsg(err));
      // availability may have changed - refresh the list
      hotelService.get(id, { checkIn, checkOut }).then((d) => setRooms(d.rooms)).catch(() => {});
    } finally { setBusy(false); }
  };

  if (loading && !hotel) return <Loader full />;
  if (error && !hotel) return <div className="container py-5"><div className="alert alert-danger">{error}</div><Link to="/hotels">Back to hotels</Link></div>;
  if (!hotel) return null;

  const imgs = hotel.images?.length ? hotel.images : [''];

  return (
    <div className="container py-4">
      <nav className="small mb-3"><Link to="/hotels">Hotels</Link> / {hotel.city} / <span className="text-muted">{hotel.name}</span></nav>

      <div className="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
        <div>
          <h1 className="h2 mb-1">{hotel.name}</h1>
          <Stars n={hotel.starRating} />
          <div className="text-muted">{hotel.address}</div>
        </div>
        <StarRating value={hotel.rating} count={hotel.reviewCount} size={18} />
      </div>

      <div className="hp-gallery mb-4">
        {[0, 1, 2, 3, 4].map((i) => <Img key={i} src={imgs[i % imgs.length]} alt={`${hotel.name} photo ${i + 1}`} />)}
      </div>

      <div className="row g-4">
        <div className="col-lg-8">
          <h4>About this hotel</h4>
          <p className="text-muted">{hotel.description}</p>
          <h5 className="mt-4">Amenities</h5>
          <div className="d-flex flex-wrap gap-2 mb-2">{hotel.amenities.map((a) => <span key={a} className="hp-chip fs-6 px-3 py-1">{a}</span>)}</div>
          <p className="small text-muted">Check-in from {hotel.policies?.checkInTime}. Check-out by {hotel.policies?.checkOutTime}.</p>

          <h4 className="mt-4" id="rooms">Choose your room</h4>
          {!datesOk && <div className="alert alert-warning">Pick a check-out date after check-in (maximum 30 nights).</div>}
          <div className="d-flex flex-column gap-3">
            {rooms.map((r) => {
              const left = r.available;
              const fits = guests <= r.capacity;
              const canBook = datesOk && left > 0 && fits;
              return (
                <div className="hp-room" key={r._id}>
                  <Img src={r.images?.[0] || hotel.images?.[0]} alt={r.name} />
                  <div className="flex-grow-1">
                    <div className="d-flex justify-content-between flex-wrap gap-2">
                      <div>
                        <h5 className="mb-0">{r.name}</h5>
                        <small className="text-muted">{r.category} · {r.bedType} bed · sleeps {r.capacity}{r.sizeSqFt ? ` · ${r.sizeSqFt} sq ft` : ''}</small>
                      </div>
                      <div className="text-end">
                        <div className="hp-price">{inr(r.pricePerNight)}<small className="text-muted fs-6"> / night</small></div>
                        {datesOk && <small className="text-muted">{inr(r.pricePerNight * nights)} for {nights} night{nights > 1 ? 's' : ''}</small>}
                      </div>
                    </div>
                    <p className="small text-muted my-2">{r.description}</p>
                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">
                      <div>
                        {left === undefined ? null : left > 0 && fits ? (
                          <span className="hp-badge hp-badge-success">{left <= 2 ? `Only ${left} left` : 'Available'}</span>
                        ) : !fits ? (
                          <span className="hp-badge hp-badge-warning">Sleeps {r.capacity} max</span>
                        ) : (
                          <span className="hp-badge hp-badge-danger">Sold out for these dates</span>
                        )}
                      </div>
                      <button className="btn btn-gold" disabled={!canBook} onClick={() => openBooking(r)}>Book this room</button>
                    </div>
                  </div>
                </div>
              );
            })}
            {rooms.length === 0 && <div className="hp-empty hp-panel">No rooms are listed for this hotel yet.</div>}
          </div>
        </div>

        <aside className="col-lg-4">
          <div className="hp-panel hp-sticky">
            <h5>Your stay</h5>
            <div className="row g-2">
              <div className="col-6"><label className="form-label" htmlFor="d-in">Check-in</label>
                <input id="d-in" type="date" className="form-control" min={dateInput(0)} value={checkIn} onChange={(e) => {
                  const v = e.target.value; setCheckIn(v);
                  if (checkOut <= v) setCheckOut(new Date(new Date(v).getTime() + 86400000).toISOString().slice(0, 10));
                }} /></div>
              <div className="col-6"><label className="form-label" htmlFor="d-out">Check-out</label>
                <input id="d-out" type="date" className="form-control" min={checkIn} value={checkOut} onChange={(e) => setCheckOut(e.target.value)} /></div>
              <div className="col-12"><label className="form-label" htmlFor="d-g">Guests</label>
                <select id="d-g" className="form-select" value={guests} onChange={(e) => setGuests(Number(e.target.value))}>
                  {[1, 2, 3, 4, 5, 6].map((n) => <option key={n} value={n}>{n} guest{n > 1 ? 's' : ''}</option>)}
                </select></div>
            </div>
            <hr />
            <div className="d-flex justify-content-between"><span>Length of stay</span><strong>{datesOk ? `${nights} night${nights > 1 ? 's' : ''}` : '-'}</strong></div>
            <div className="d-flex justify-content-between"><span>Rooms from</span><strong>{inr(hotel.startingPrice)} / night</strong></div>
            <p className="small text-muted mt-3 mb-0">Room availability on the left updates for your dates. You pay after the booking is created.</p>
          </div>
        </aside>
      </div>

      <Modal show={!!selected} onClose={() => !busy && setSelected(null)} title="Confirm your booking">
        {selected && (
          <form onSubmit={confirm}>
            <div className="bg-beige rounded p-3 mb-3 small">
              <strong>{hotel.name}</strong> · {selected.name}<br />
              {checkIn} to {checkOut} · {guests} guest{guests > 1 ? 's' : ''}<br />
              {inr(selected.pricePerNight)} × {nights} night{nights > 1 ? 's' : ''}
              <div className="fs-5 mt-1"><strong>Total {inr(total)}</strong></div>
            </div>
            {formErr && <div className="alert alert-danger py-2">{formErr}</div>}
            <div className="mb-2"><label className="form-label" htmlFor="g-name">Guest name</label>
              <input id="g-name" className="form-control" required minLength={2} value={form.guestName} onChange={(e) => setForm({ ...form, guestName: e.target.value })} /></div>
            <div className="mb-2"><label className="form-label" htmlFor="g-phone">Phone</label>
              <input id="g-phone" className="form-control" pattern="[0-9+\- ]{7,15}" title="7-15 digits" value={form.guestPhone} onChange={(e) => setForm({ ...form, guestPhone: e.target.value })} /></div>
            <div className="mb-3"><label className="form-label" htmlFor="g-req">Special requests (optional)</label>
              <textarea id="g-req" className="form-control" rows="2" maxLength={500} value={form.specialRequests} onChange={(e) => setForm({ ...form, specialRequests: e.target.value })} /></div>
            <button className="btn btn-gold w-100" disabled={busy}>{busy ? 'Booking…' : `Confirm booking · ${inr(total)}`}</button>
          </form>
        )}
      </Modal>
    </div>
  );
}
