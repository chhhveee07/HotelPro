import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { paymentService } from '../services/api-helpers';
import Loader from '../components/Loader';
import StatusBadge from '../components/StatusBadge';
import { fmtDate, inr } from '../utils';

export default function MyPayments() {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { paymentService.mine().then((d) => setPayments(d.payments)).finally(() => setLoading(false)); }, []);

  return (
    <>
      <div className="hp-page-head"><div className="container"><h1>Payment history</h1></div></div>
      <div className="container py-4">
        {loading ? <Loader /> : payments.length === 0 ? (
          <div className="hp-empty hp-panel"><h5>No payments yet</h5><p>Payments appear here after you pay for a booking.</p><Link to="/hotels" className="btn btn-hp">Find a hotel</Link></div>
        ) : (
          <div className="hp-table table-responsive">
            <table className="table table-hover">
              <thead><tr><th>Date</th><th>Booking</th><th>Hotel</th><th>Method</th><th>Transaction</th><th className="text-end">Amount</th><th>Status</th></tr></thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p._id}>
                    <td>{fmtDate(p.createdAt)}</td>
                    <td>{p.booking ? <Link to={`/bookings/${p.booking._id}`}>{p.booking.bookingId}</Link> : '-'}</td>
                    <td>{p.booking?.hotel?.name || '-'}</td>
                    <td className="text-capitalize">{p.method}{p.method === 'simulated' ? ' (demo)' : ''}</td>
                    <td className="small text-break">{p.transactionId || '-'}</td>
                    <td className="text-end fw-semibold">{inr(p.amount)}</td>
                    <td><StatusBadge status={p.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
