import { useEffect, useState } from 'react';
import { hotelService, errMsg } from '../services/api-helpers';
import { useToast } from '../context/ToastContext';
import Loader from '../components/Loader';
import Modal from '../components/Modal';
import ConfirmModal from '../components/ConfirmModal';
import Img from '../components/ImageWithFallback';
import { inr } from '../utils';

const EMPTY = { name: '', description: '', city: '', state: '', country: 'India', address: '', starRating: 4, rating: 4, amenities: '', images: '', featured: false, isActive: true };

export default function ManageHotels() {
  const toast = useToast();
  const [hotels, setHotels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null); // null = closed
  const [editing, setEditing] = useState(null);
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [del, setDel] = useState(null);

  const load = () => hotelService.adminAll().then((d) => setHotels(d.hotels)).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const openNew = () => { setEditing(null); setForm(EMPTY); setFiles([]); setErr(''); };
  const openEdit = (h) => {
    setEditing(h); setFiles([]); setErr('');
    setForm({ ...h, amenities: (h.amenities || []).join(', '), images: (h.images || []).join('\n') });
  };
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const save = async (e) => {
    e.preventDefault(); setBusy(true); setErr('');
    const body = {
      name: form.name, description: form.description, city: form.city, state: form.state, country: form.country, address: form.address,
      starRating: Number(form.starRating), rating: Number(form.rating), featured: form.featured, isActive: form.isActive,
      amenities: form.amenities.split(',').map((s) => s.trim()).filter(Boolean),
      images: form.images.split(/[\n,]/).map((s) => s.trim()).filter(Boolean),
    };
    try {
      const d = editing ? await hotelService.update(editing._id, body) : await hotelService.create(body);
      if (files.length) await hotelService.uploadImages(d.hotel._id, files);
      toast.success(editing ? 'Hotel updated' : 'Hotel added');
      setForm(null); load();
    } catch (er) { setErr(errMsg(er)); } finally { setBusy(false); }
  };

  const remove = async () => {
    setBusy(true);
    try { await hotelService.remove(del._id); toast.success('Hotel deleted'); setDel(null); load(); }
    catch (er) { toast.error(errMsg(er)); setDel(null); } finally { setBusy(false); }
  };

  const removeImage = async (url) => {
    try { const d = await hotelService.removeImage(editing._id, url); setEditing(d.hotel); setForm({ ...form, images: d.hotel.images.join('\n') }); load(); }
    catch (er) { setErr(errMsg(er)); }
  };

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div><h2 className="mb-0">Hotels</h2><p className="text-muted mb-0">Add, edit and remove hotel listings.</p></div>
        <button className="btn btn-gold" onClick={openNew}>Add hotel</button>
      </div>
      {loading ? <Loader /> : (
        <div className="hp-table table-responsive">
          <table className="table table-hover">
            <thead><tr><th></th><th>Hotel</th><th>City</th><th>Stars</th><th>Rating</th><th>Rooms</th><th>From</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {hotels.map((h) => (
                <tr key={h._id}>
                  <td><Img className="thumb" src={h.images?.[0]} alt="" /></td>
                  <td><strong>{h.name}</strong>{h.featured && <span className="hp-chip ms-2">Featured</span>}</td>
                  <td>{h.city}</td><td>{h.starRating}★</td><td>{h.rating}</td><td>{h.roomCount}</td><td>{inr(h.startingPrice)}</td>
                  <td><span className={`hp-badge ${h.isActive ? 'hp-badge-success' : 'hp-badge-secondary'}`}>{h.isActive ? 'active' : 'hidden'}</span></td>
                  <td className="text-end text-nowrap">
                    <button className="btn btn-sm btn-outline-hp me-1" onClick={() => openEdit(h)}>Edit</button>
                    <button className="btn btn-sm btn-outline-danger" onClick={() => setDel(h)}>Delete</button>
                  </td>
                </tr>
              ))}
              {!hotels.length && <tr><td colSpan="9" className="text-center text-muted py-4">No hotels yet. Click “Add hotel”.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      <Modal show={!!form} size="lg" onClose={() => !busy && setForm(null)} title={editing ? `Edit ${editing.name}` : 'Add hotel'}>
        {form && (
          <form onSubmit={save}>
            {err && <div className="alert alert-danger py-2">{err}</div>}
            <div className="row g-3">
              <div className="col-md-8"><label className="form-label">Hotel name</label><input className="form-control" required value={form.name} onChange={set('name')} /></div>
              <div className="col-md-4"><label className="form-label">City</label><input className="form-control" required value={form.city} onChange={set('city')} /></div>
              <div className="col-md-4"><label className="form-label">State</label><input className="form-control" value={form.state || ''} onChange={set('state')} /></div>
              <div className="col-md-4"><label className="form-label">Country</label><input className="form-control" value={form.country || ''} onChange={set('country')} /></div>
              <div className="col-md-2"><label className="form-label">Stars</label><select className="form-select" value={form.starRating} onChange={set('starRating')}>{[1, 2, 3, 4, 5].map((n) => <option key={n}>{n}</option>)}</select></div>
              <div className="col-md-2"><label className="form-label">Rating</label><input type="number" min="0" max="5" step="0.1" className="form-control" value={form.rating} onChange={set('rating')} /></div>
              <div className="col-12"><label className="form-label">Address</label><input className="form-control" required value={form.address} onChange={set('address')} /></div>
              <div className="col-12"><label className="form-label">Description</label><textarea className="form-control" rows="3" required value={form.description} onChange={set('description')} /></div>
              <div className="col-12"><label className="form-label">Amenities (comma separated)</label><input className="form-control" value={form.amenities} onChange={set('amenities')} placeholder="Free WiFi, Pool, Spa" /></div>
              <div className="col-12"><label className="form-label">Image URLs (one per line)</label><textarea className="form-control" rows="2" value={form.images} onChange={set('images')} /></div>
              <div className="col-12">
                <label className="form-label">Upload images (JPG, PNG, WEBP up to 5 MB each)</label>
                <input type="file" multiple accept="image/*" className="form-control" onChange={(e) => setFiles(e.target.files)} />
                {editing && editing.images?.some((i) => i.startsWith('/uploads')) && (
                  <div className="d-flex flex-wrap gap-2 mt-2">
                    {editing.images.filter((i) => i.startsWith('/uploads')).map((i) => (
                      <div key={i} className="position-relative"><Img className="thumb" src={i} alt="" />
                        <button type="button" className="btn btn-danger btn-sm position-absolute top-0 end-0 py-0 px-1" onClick={() => removeImage(i)} aria-label="Remove image">×</button></div>
                    ))}
                  </div>
                )}
              </div>
              <div className="col-6 col-md-3"><div className="form-check"><input id="h-f" type="checkbox" className="form-check-input" checked={!!form.featured} onChange={set('featured')} /><label htmlFor="h-f" className="form-check-label">Featured</label></div></div>
              <div className="col-6 col-md-3"><div className="form-check"><input id="h-a" type="checkbox" className="form-check-input" checked={!!form.isActive} onChange={set('isActive')} /><label htmlFor="h-a" className="form-check-label">Visible to guests</label></div></div>
            </div>
            <div className="d-flex justify-content-end gap-2 mt-4">
              <button type="button" className="btn btn-outline-secondary" onClick={() => setForm(null)} disabled={busy}>Cancel</button>
              <button className="btn btn-hp" disabled={busy}>{busy ? 'Saving…' : 'Save hotel'}</button>
            </div>
          </form>
        )}
      </Modal>
      <ConfirmModal show={!!del} danger busy={busy} title="Delete this hotel?" confirmText="Delete hotel"
        message={del ? `${del.name} and all its rooms will be permanently removed. Hotels with upcoming bookings cannot be deleted.` : ''}
        onConfirm={remove} onCancel={() => setDel(null)} />
    </>
  );
}
