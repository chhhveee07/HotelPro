import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { bookingService, paymentService } from '../services/api-helpers';
import { useAuth } from '../context/AuthContext';
import Loader from '../components/Loader';
import StatusBadge from '../components/StatusBadge';
import { fmtDate, inr } from '../utils';

export default function CustomerDashboard() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([bookingService.mine(), paymentService.mine()])
      .then(([b, p]) => { setBookings(b.bookings); setPayments(p.payments); })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader full />;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const upcoming = bookings.filter((b) => ['pending', 'confirmed'].includes(b.status) && new Date(b.checkOut) > today);
  const spent = payments.filter((p) => p.status === 'successful').reduce((s, p) => s + p.amount, 0);
  const next = [...upcoming].sort((a, b) => new Date(a.checkIn) - new Date(b.checkIn))[0];

  return (
    <>
      <div className="hp-page-head"><div className="container"><h1>Hello, {user.name.split(' ')[0]}</h1><p className="text-muted mb-0">Here is a snapshot of your trips.</p></div></div>
      <div className="container py-4">
        <div className="row g-3 mb-4">
          {[['Total bookings', bookings.length], ['Upcoming stays', upcoming.length], ['Total paid', inr(spent)], ['Payments made', payments.filter((p) => p.status === 'successful').length]].map(([l, v]) => (
            <div className="col-6 col-lg-3" key={l}><div className="stat-card"><div className="v">{v}</div><div className="l">{l}</div></div></div>
          ))}
        </div>

        <div className="row g-4">
          <div className="col-lg-7">
            <div className="hp-panel">
              <div className="d-flex justify-content-between align-items-center mb-3"><h5 className="mb-0">Recent bookings</h5><Link to="/my-bookings">View all</Link></div>
              {bookings.length === 0 ? (
                <div className="hp-empty"><h5>No bookings yet</h5><p>Find a hotel and your reservations will appear here.</p><Link className="btn btn-hp" to="/hotels">Find a hotel</Link></div>
              ) : bookings.slice(0, 5).map((b) => (
                <Link to={`/bookings/${b._id}`} key={b._id} className="d-flex justify-content-between align-items-center py-2 border-bottom text-decoration-none text-dark">
                  <div><strong>{b.hotel?.name}</strong><div className="small text-muted">{fmtDate(b.checkIn)} to {fmtDate(b.checkOut)} · {b.bookingId}</div></div>
                  <div className="text-end"><StatusBadge status={b.status} /><div className="small mt-1">{inr(b.totalPrice)}</div></div>
                </Link>
              ))}
            </div>
          </div>
          <div className="col-lg-5">
            <div className="hp-panel mb-3">
              <h5>Next stay</h5>
              {next ? (
                <>
                  <div className="fw-semibold">{next.hotel?.name}, {next.hotel?.city}</div>
                  <div className="text-muted small mb-2">{fmtDate(next.checkIn)} to {fmtDate(next.checkOut)} · {next.nights} night(s)</div>
                  <StatusBadge status={next.status} />
                  <div className="mt-3"><Link className="btn btn-outline-hp btn-sm" to={`/bookings/${next._id}`}>View booking</Link></div>
                </>
              ) : <p className="text-muted mb-0">No upcoming stays.</p>}
            </div>
            <div className="hp-panel">
              <h5>Quick links</h5>
              <div className="d-grid gap-2">
                <Link className="btn btn-hp" to="/hotels">Book a new stay</Link>
                <Link className="btn btn-outline-hp" to="/payments">Payment history</Link>
                <Link className="btn btn-outline-hp" to="/profile">Edit profile</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
