import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { errMsg } from '../services/api';

export default function Register() {
  const { register } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirm: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm) return setError('Passwords do not match');
    setBusy(true); setError('');
    try {
      const { confirm, ...body } = form;
      await register(body);
      toast.success('Account created. Welcome to HotelPro!');
      navigate('/dashboard', { replace: true });
    } catch (err) { setError(errMsg(err)); } finally { setBusy(false); }
  };

  return (
    <div className="hp-auth">
      <form className="hp-auth-card" onSubmit={submit}>
        <h2 className="h3">Create your account</h2>
        <p className="text-muted">Book rooms and manage your trips in one place.</p>
        {error && <div className="alert alert-danger py-2">{error}</div>}
        <div className="mb-3"><label className="form-label" htmlFor="name">Full name</label>
          <input id="name" className="form-control" required minLength={2} value={form.name} onChange={set('name')} /></div>
        <div className="mb-3"><label className="form-label" htmlFor="email">Email</label>
          <input id="email" type="email" className="form-control" required value={form.email} onChange={set('email')} /></div>
        <div className="mb-3"><label className="form-label" htmlFor="phone">Phone (optional)</label>
          <input id="phone" className="form-control" pattern="[0-9+\- ]{7,15}" title="7-15 digits" value={form.phone} onChange={set('phone')} /></div>
        <div className="row g-2 mb-4">
          <div className="col-6"><label className="form-label" htmlFor="password">Password</label>
            <input id="password" type="password" className="form-control" required minLength={6} autoComplete="new-password" value={form.password} onChange={set('password')} /></div>
          <div className="col-6"><label className="form-label" htmlFor="confirm">Confirm</label>
            <input id="confirm" type="password" className="form-control" required minLength={6} autoComplete="new-password" value={form.confirm} onChange={set('confirm')} /></div>
        </div>
        <button className="btn btn-hp w-100" disabled={busy}>{busy ? 'Creating account…' : 'Create account'}</button>
        <p className="text-center small mt-3 mb-0">Already registered? <Link to="/login">Log in</Link></p>
      </form>
    </div>
  );
}
