import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errMsg } from '../services/api';
import Logo from '../components/Logo';

export default function AdminLogin() {
  const { adminLogin } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    try { await adminLogin(form); navigate('/admin', { replace: true }); }
    catch (err) { setError(errMsg(err)); } finally { setBusy(false); }
  };

  return (
    <div className="hp-auth" style={{ background: 'var(--navy)', minHeight: '100vh' }}>
      <form className="hp-auth-card" onSubmit={submit}>
        <div className="mb-3"><Logo /></div>
        <h2 className="h4">Administrator sign in</h2>
        <p className="text-muted small">Restricted to hotel staff.</p>
        {error && <div className="alert alert-danger py-2">{error}</div>}
        <div className="mb-3"><label className="form-label" htmlFor="email">Admin email</label>
          <input id="email" type="email" className="form-control" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
        <div className="mb-4"><label className="form-label" htmlFor="password">Password</label>
          <input id="password" type="password" className="form-control" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
        <button className="btn btn-hp w-100" disabled={busy}>{busy ? 'Signing in…' : 'Sign in to admin'}</button>
        <p className="text-center small mt-3 mb-0"><Link to="/">Back to website</Link></p>
      </form>
    </div>
  );
}
