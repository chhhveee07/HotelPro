import axios from 'axios';

export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
export const FILE_URL = API_URL.replace(/\/api\/?$/, '');

const api = axios.create({ baseURL: API_URL, timeout: 20000 });

// Attach JWT to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('hp_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Expired / invalid token -> force logout (but not for login attempts themselves)
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const isAuthCall = err.config?.url?.startsWith('/auth/');
    if (err.response?.status === 401 && !isAuthCall && localStorage.getItem('hp_token')) {
      window.dispatchEvent(new Event('hp:unauthorized'));
    }
    return Promise.reject(err);
  }
);

// Human-friendly message from any axios error
export const errMsg = (err) => {
  const d = err?.response?.data;
  if (d?.errors?.length) return d.errors.map((e) => e.message).join('. ');
  return d?.message || (err?.code === 'ERR_NETWORK' ? 'Cannot reach the server. Is the backend running?' : err?.message) || 'Something went wrong';
};

export default api;
