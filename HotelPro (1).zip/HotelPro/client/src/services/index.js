import api from './api';

const unwrap = (p) => p.then((r) => r.data);

export const authService = {
  register: (body) => unwrap(api.post('/auth/register', body)),
  login: (body) => unwrap(api.post('/auth/login', body)),
  adminLogin: (body) => unwrap(api.post('/auth/admin-login', body)),
  me: () => unwrap(api.get('/auth/me')),
};

export const userService = {
  updateProfile: (body) => unwrap(api.put('/users/profile', body)),
  changePassword: (body) => unwrap(api.put('/users/password', body)),
  list: (params) => unwrap(api.get('/users', { params })),
  get: (id) => unwrap(api.get(`/users/${id}`)),
  update: (id, body) => unwrap(api.put(`/users/${id}`, body)),
};

export const hotelService = {
  list: (params) => unwrap(api.get('/hotels', { params })),
  destinations: () => unwrap(api.get('/hotels/destinations')),
  get: (id, params) => unwrap(api.get(`/hotels/${id}`, { params })),
  adminAll: () => unwrap(api.get('/hotels/admin/all')),
  create: (body) => unwrap(api.post('/hotels', body)),
  update: (id, body) => unwrap(api.put(`/hotels/${id}`, body)),
  remove: (id) => unwrap(api.delete(`/hotels/${id}`)),
  uploadImages: (id, files) => {
    const fd = new FormData();
    [...files].forEach((f) => fd.append('images', f));
    return unwrap(api.post(`/hotels/${id}/images`, fd));
  },
  removeImage: (id, url) => unwrap(api.delete(`/hotels/${id}/images`, { params: { url } })),
};

export const roomService = {
  all: (params) => unwrap(api.get('/rooms', { params })),
  availability: (id, params) => unwrap(api.get(`/rooms/${id}/availability`, { params })),
  create: (body) => unwrap(api.post('/rooms', body)),
  update: (id, body) => unwrap(api.put(`/rooms/${id}`, body)),
  updatePrice: (id, pricePerNight) => unwrap(api.patch(`/rooms/${id}/price`, { pricePerNight })),
  remove: (id) => unwrap(api.delete(`/rooms/${id}`)),
  uploadImages: (id, files) => {
    const fd = new FormData();
    [...files].forEach((f) => fd.append('images', f));
    return unwrap(api.post(`/rooms/${id}/images`, fd));
  },
};

export const bookingService = {
  create: (body) => unwrap(api.post('/bookings', body)),
  mine: (params) => unwrap(api.get('/bookings/my', { params })),
  get: (id) => unwrap(api.get(`/bookings/${id}`)),
  cancel: (id) => unwrap(api.patch(`/bookings/${id}/cancel`)),
  adminAll: (params) => unwrap(api.get('/bookings', { params })),
  setStatus: (id, status) => unwrap(api.patch(`/bookings/${id}/status`, { status })),
};

export const paymentService = {
  config: () => unwrap(api.get('/payments/config')),
  createOrder: (bookingId) => unwrap(api.post('/payments/create-order', { bookingId })),
  verify: (body) => unwrap(api.post('/payments/verify', body)),
  simulate: (paymentId, outcome) => unwrap(api.post('/payments/simulate', { paymentId, outcome })),
  mine: () => unwrap(api.get('/payments/my')),
  adminAll: (params) => unwrap(api.get('/payments', { params })),
  refund: (id) => unwrap(api.patch(`/payments/${id}/refund`)),
};

export const adminService = {
  stats: () => unwrap(api.get('/admin/stats')),
  revenue: (params) => unwrap(api.get('/admin/revenue', { params })),
  occupancy: (params) => unwrap(api.get('/admin/occupancy', { params })),
};
