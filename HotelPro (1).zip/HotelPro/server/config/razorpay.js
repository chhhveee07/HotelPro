// Razorpay is optional. If keys are missing, the app uses the simulated gateway.
let instance = null;

const isRazorpayEnabled = () =>
  Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);

const getRazorpay = () => {
  if (!isRazorpayEnabled()) return null;
  if (!instance) {
    const Razorpay = require('razorpay');
    instance = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
  }
  return instance;
};

module.exports = { getRazorpay, isRazorpayEnabled };
