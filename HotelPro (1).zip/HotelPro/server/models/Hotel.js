const mongoose = require('mongoose');

const hotelSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, 'Hotel name is required'], trim: true, maxlength: 120 },
    description: { type: String, required: [true, 'Description is required'], maxlength: 3000 },
    city: { type: String, required: [true, 'City is required'], trim: true, index: true },
    state: { type: String, trim: true },
    country: { type: String, trim: true, default: 'India' },
    address: { type: String, required: [true, 'Address is required'], trim: true },
    images: [{ type: String }],
    amenities: [{ type: String, trim: true }],
    starRating: { type: Number, min: 1, max: 5, default: 4 },
    rating: { type: Number, min: 0, max: 5, default: 0 },
    reviewCount: { type: Number, min: 0, default: 0 },
    startingPrice: { type: Number, min: 0, default: 0 }, // lowest active room price (kept in sync)
    featured: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    policies: {
      checkInTime: { type: String, default: '14:00' },
      checkOutTime: { type: String, default: '11:00' },
    },
  },
  { timestamps: true }
);

hotelSchema.index({ name: 'text', city: 'text', description: 'text' });

module.exports = mongoose.model('Hotel', hotelSchema);
