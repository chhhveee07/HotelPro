const mongoose = require('mongoose');

// NOTE: Card details are NEVER stored. Only gateway references are kept.
const paymentSchema = new mongoose.Schema(
  {
    booking: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true, index: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    amount: { type: Number, required: true, min: 0 },
    currency: { type: String, default: 'INR' },
    method: { type: String, enum: ['razorpay', 'simulated'], required: true },
    status: { type: String, enum: ['pending', 'successful', 'failed', 'refunded'], default: 'pending', index: true },
    transactionId: { type: String, unique: true, sparse: true },
    razorpayOrderId: String,
    razorpayPaymentId: String,
    paidAt: Date,
    refundedAt: Date,
    failureReason: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Payment', paymentSchema);
