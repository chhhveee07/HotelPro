const mongoose = require('mongoose');

const roomSchema = new mongoose.Schema(
  {
    hotel: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true, index: true },
    name: { type: String, required: [true, 'Room name is required'], trim: true, maxlength: 100 },
    category: {
      type: String,
      enum: ['Standard', 'Deluxe', 'Suite', 'Executive', 'Family', 'Presidential'],
      default: 'Standard',
    },
    description: { type: String, maxlength: 1500 },
    pricePerNight: { type: Number, required: [true, 'Price is required'], min: [1, 'Price must be positive'] },
    capacity: { type: Number, required: true, min: 1, max: 10, default: 2 },
    quantity: { type: Number, required: true, min: 1, default: 1 }, // how many rooms of this type exist
    bedType: { type: String, default: 'Queen' },
    sizeSqFt: { type: Number, min: 0 },
    amenities: [{ type: String, trim: true }],
    images: [{ type: String }],
    isActive: { type: Boolean, default: true },
    // Incremented inside the booking transaction. Forces concurrent bookings on
    // the same room to conflict and serialize, which prevents double bookings.
    bookingVersion: { type: Number, default: 0, select: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Room', roomSchema);
