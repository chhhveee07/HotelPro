/* End-to-end API smoke test. Start the server (with seeded data) first, then:
 *   node tests/smoke.js            (Node 18+, uses global fetch)
 * Set BASE=https://your-api/api to test a deployed API.                         */
const BASE = process.env.BASE || 'http://localhost:5000/api';
let passed = 0, failed = 0;

const call = async (method, path, body, token) => {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch (_e) { /* empty */ }
  return { status: res.status, data };
};
const check = (name, cond, extra = '') => {
  if (cond) { passed += 1; console.log(`  PASS  ${name}`); } else { failed += 1; console.log(`  FAIL  ${name} ${extra}`); }
};
const day = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);

(async () => {
  console.log(`Smoke test against ${BASE}\n`);
  const email = `smoke${Date.now()}@example.com`;

  let r = await call('GET', '/health');
  check('health endpoint', r.status === 200);

  r = await call('POST', '/auth/register', { name: 'Smoke Tester', email, password: 'secret12', phone: '9999999999' });
  check('register -> 201', r.status === 201 && r.data.token);
  check('register never returns password hash', !('password' in (r.data.user || {})));
  const token = r.data.token;

  r = await call('POST', '/auth/register', { name: 'Dup', email, password: 'secret12' });
  check('duplicate email -> 409', r.status === 409);

  r = await call('POST', '/auth/register', { name: 'X', email: 'bad', password: '1' });
  check('invalid input -> 400', r.status === 400);

  r = await call('POST', '/auth/login', { email, password: 'wrong' });
  check('wrong password -> 401', r.status === 401);

  r = await call('POST', '/auth/login', { email, password: 'secret12' });
  check('login -> 200', r.status === 200 && r.data.token);

  r = await call('GET', '/bookings/my');
  check('protected route without token -> 401', r.status === 401);

  r = await call('GET', '/admin/stats', null, token);
  check('customer blocked from admin route -> 403', r.status === 403);

  r = await call('GET', '/hotels?limit=3&sort=rating');
  check('list hotels', r.status === 200 && r.data.hotels.length > 0, '(did you run npm run seed?)');
  const hotel = r.data.hotels[0];

  r = await call('GET', `/hotels?minPrice=1&maxPrice=100000&rating=4&city=${encodeURIComponent(hotel.city)}`);
  check('filter by price, rating and city', r.status === 200 && r.data.hotels.length > 0);

  r = await call('GET', `/hotels/${hotel._id}?checkIn=${day(10)}&checkOut=${day(12)}`);
  check('hotel details with availability', r.status === 200 && r.data.rooms.length > 0 && 'available' in r.data.rooms[0]);
  const room = r.data.rooms.find((x) => x.quantity === Math.min(...r.data.rooms.map((y) => y.quantity))) || r.data.rooms[0];

  r = await call('GET', `/rooms/${room._id}/availability?checkIn=${day(10)}&checkOut=${day(12)}&guests=2`);
  check('room availability check', r.status === 200 && r.data.available === true);

  r = await call('POST', '/bookings', { roomId: room._id, checkIn: day(2), checkOut: day(1), guests: 2 }, token);
  check('invalid dates rejected -> 400', r.status === 400);

  r = await call('POST', '/bookings', { roomId: room._id, checkIn: day(40), checkOut: day(42), guests: 2 }, token);
  check('create booking -> 201 with booking ID', r.status === 201 && /^HP-/.test(r.data.booking?.bookingId || ''), JSON.stringify(r.data));
  const booking = r.data.booking;

  // Concurrency: fire many simultaneous bookings for a 1-unit room, only `quantity` may succeed
  const singles = await call('GET', '/rooms/' + room._id);
  const qty = singles.data.room.quantity;
  const results = await Promise.all(
    Array.from({ length: qty + 3 }, () => call('POST', '/bookings', { roomId: room._id, checkIn: day(60), checkOut: day(62), guests: 1 }, token))
  );
  const ok = results.filter((x) => x.status === 201).length;
  check(`no double booking: ${qty + 3} parallel requests, ${qty} unit(s) -> ${ok} succeeded`, ok === qty);

  r = await call('POST', '/payments/create-order', { bookingId: booking._id }, token);
  check('create payment order', r.status === 201);
  if (r.data.mode === 'simulated') {
    r = await call('POST', '/payments/simulate', { paymentId: r.data.payment._id, outcome: 'success' }, token);
    check('simulated payment succeeds', r.status === 200 && r.data.payment.status === 'successful');
    r = await call('GET', `/bookings/${booking._id}`, null, token);
    check('booking confirmed after payment', r.data.booking.status === 'confirmed');
  }

  r = await call('GET', '/payments/my', null, token);
  check('payment history', r.status === 200 && r.data.payments.length >= 1);

  r = await call('PATCH', `/bookings/${booking._id}/cancel`, null, token);
  check('cancel booking (refunds paid booking)', r.status === 200 && r.data.booking.status === 'cancelled');

  r = await call('POST', '/auth/admin-login', { email: process.env.ADMIN_EMAIL || 'admin@hotelpro.com', password: process.env.ADMIN_PASSWORD || 'Admin@12345' });
  check('admin login', r.status === 200 && r.data.user?.role === 'admin');
  const admin = r.data.token;
  if (admin) {
    r = await call('GET', '/admin/stats', null, admin);
    check('admin stats from real data', r.status === 200 && typeof r.data.stats.totalHotels === 'number');
    r = await call('GET', '/admin/revenue', null, admin);
    check('revenue report', r.status === 200);
    r = await call('GET', '/users', null, admin);
    check('admin lists customers', r.status === 200 && Array.isArray(r.data.users));
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
