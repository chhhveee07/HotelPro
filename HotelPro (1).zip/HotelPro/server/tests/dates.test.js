// Run: npm test   (uses Node's built-in test runner, no extra dependencies)
const test = require('node:test');
const assert = require('node:assert');
const { parseStay, nightsBetween, toUTCDate, eachNight } = require('../utils/dates');

const future = (days) => new Date(Date.now() + days * 86400000).toISOString().slice(0, 10);

test('nightsBetween counts nights', () => {
  assert.strictEqual(nightsBetween(toUTCDate('2030-01-01'), toUTCDate('2030-01-04')), 3);
});

test('eachNight excludes the check-out day', () => {
  const nights = eachNight(toUTCDate('2030-01-01'), toUTCDate('2030-01-03'));
  assert.strictEqual(nights.length, 2);
});

test('parseStay accepts a valid future stay', () => {
  const s = parseStay(future(5), future(8));
  assert.strictEqual(s.nights, 3);
});

test('parseStay rejects check-out before check-in', () => {
  assert.throws(() => parseStay(future(8), future(5)), /after check-in/);
});

test('parseStay rejects past check-in', () => {
  assert.throws(() => parseStay('2000-01-01', '2000-01-03'), /past/);
});

test('parseStay rejects stays longer than 30 nights', () => {
  assert.throws(() => parseStay(future(2), future(40)), /Maximum stay/);
});
