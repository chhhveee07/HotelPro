const Hotel = require('../models/Hotel');
const Room = require('../models/Room');
const Booking = require('../models/Booking');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { parseStay, todayUTC } = require('../utils/dates');
const { availableUnits, ACTIVE_STATUSES } = require('../utils/availability');
const { syncHotelStartingPrice } = require('../utils/hotelSync');

const parseList = (v) => (Array.isArray(v) ? v : typeof v === 'string' ? v.split(',').map((s) => s.trim()).filter(Boolean) : undefined);
const ROOM_FIELDS = ['name', 'category', 'description', 'pricePerNight', 'capacity', 'quantity', 'bedType', 'sizeSqFt', 'isActive'];

// GET /api/hotels/:hotelId/rooms (public)
exports.getRoomsByHotel = asyncHandler(async (req, res) => {
  const rooms = await Room.find({ hotel: req.params.hotelId, isActive: true }).sort('pricePerNight');
  res.json({ success: true, rooms });
});

// GET /api/rooms (admin) ?hotel=
exports.getAllRooms = asyncHandler(async (req, res) => {
  const filter = req.query.hotel ? { hotel: req.query.hotel } : {};
  const rooms = await Room.find(filter).populate('hotel', 'name city').sort('-createdAt');
  res.json({ success: true, rooms });
});

// GET /api/rooms/:id (public)
exports.getRoom = asyncHandler(async (req, res) => {
  const room = await Room.findById(req.params.id).populate('hotel', 'name city images');
  if (!room) throw new ApiError(404, 'Room not found');
  res.json({ success: true, room });
});

// GET /api/rooms/:id/availability?checkIn=&checkOut=  (public)
exports.checkAvailability = asyncHandler(async (req, res) => {
  const room = await Room.findById(req.params.id);
  if (!room || !room.isActive) throw new ApiError(404, 'Room not found');
  const { checkIn, checkOut, nights } = parseStay(req.query.checkIn, req.query.checkOut);
  const guests = Number(req.query.guests) || 1;
  const units = await availableUnits(room, checkIn, checkOut);
  const fitsGuests = guests <= room.capacity;
  res.json({
    success: true,
    available: units > 0 && fitsGuests,
    unitsLeft: units,
    fitsGuests,
    nights,
    pricePerNight: room.pricePerNight,
    totalPrice: nights * room.pricePerNight,
  });
});

// POST /api/rooms (admin)
exports.createRoom = asyncHandler(async (req, res) => {
  const hotel = await Hotel.findById(req.body.hotel);
  if (!hotel) throw new ApiError(404, 'Hotel not found');
  const data = { hotel: hotel._id };
  ROOM_FIELDS.forEach((f) => req.body[f] !== undefined && (data[f] = req.body[f]));
  data.amenities = parseList(req.body.amenities) || [];
  data.images = parseList(req.body.images) || [];
  const room = await Room.create(data);
  await syncHotelStartingPrice(hotel._id);
  res.status(201).json({ success: true, room });
});

// PUT /api/rooms/:id (admin)
exports.updateRoom = asyncHandler(async (req, res) => {
  const room = await Room.findById(req.params.id);
  if (!room) throw new ApiError(404, 'Room not found');
  ROOM_FIELDS.forEach((f) => req.body[f] !== undefined && (room[f] = req.body[f]));
  if (req.body.amenities !== undefined) room.amenities = parseList(req.body.amenities) || [];
  if (req.body.images !== undefined) room.images = parseList(req.body.images) || [];
  await room.save();
  await syncHotelStartingPrice(room.hotel);
  res.json({ success: true, room });
});

// PATCH /api/rooms/:id/price (admin) - manage room prices
exports.updatePrice = asyncHandler(async (req, res) => {
  const room = await Room.findByIdAndUpdate(req.params.id, { pricePerNight: req.body.pricePerNight }, { new: true, runValidators: true });
  if (!room) throw new ApiError(404, 'Room not found');
  await syncHotelStartingPrice(room.hotel);
  res.json({ success: true, room });
});

// DELETE /api/rooms/:id (admin)
exports.deleteRoom = asyncHandler(async (req, res) => {
  const room = await Room.findById(req.params.id);
  if (!room) throw new ApiError(404, 'Room not found');
  const upcoming = await Booking.countDocuments({ room: room._id, status: { $in: ACTIVE_STATUSES }, checkOut: { $gt: todayUTC() } });
  if (upcoming > 0) throw new ApiError(409, `Cannot delete: ${upcoming} upcoming booking(s) exist for this room`);
  await room.deleteOne();
  await syncHotelStartingPrice(room.hotel);
  res.json({ success: true, message: 'Room deleted' });
});

// POST /api/rooms/:id/images (admin)
exports.uploadImages = asyncHandler(async (req, res) => {
  const room = await Room.findById(req.params.id);
  if (!room) throw new ApiError(404, 'Room not found');
  if (!req.files || !req.files.length) throw new ApiError(400, 'No images uploaded');
  room.images.push(...req.files.map((f) => `/uploads/${f.filename}`));
  await room.save();
  res.status(201).json({ success: true, room });
});
