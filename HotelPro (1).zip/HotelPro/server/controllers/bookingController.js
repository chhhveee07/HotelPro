const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const Room = require('../models/Room');
const Hotel = require('../models/Hotel');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { parseStay, todayUTC } = require('../utils/dates');
const { availableUnits, runInTransaction } = require('../utils/availability');
const { refundPayment } = require('../utils/paymentService');
const { markCompletedBookings } = require('../utils/maintenance');

const populateBooking = (q) =>
  q.populate('hotel', 'name city address images policies').populate('room', 'name category pricePerNight images').populate('user', 'name email phone');

// POST /api/bookings  (customer)
// Double-booking protection:
//  1. Everything happens inside a MongoDB transaction.
//  2. The room document is "touched" ($inc bookingVersion) first. Two concurrent
//     transactions on the same room therefore collide (write conflict), one is retried
//     and then sees the other's booking in its overlap check and is rejected.
//  3. Overlap rule: existing.checkIn < new.checkOut AND existing.checkOut > new.checkIn
exports.createBooking = asyncHandler(async (req, res) => {
  const { roomId, guests, guestName, guestPhone, specialRequests } = req.body;
  const { checkIn, checkOut, nights } = parseStay(req.body.checkIn, req.body.checkOut);
  const guestCount = Number(guests);

  const booking = await runInTransaction(async (session) => {
    const room = await Room.findOneAndUpdate(
      { _id: roomId, isActive: true },
      { $inc: { bookingVersion: 1 } },
      { new: true, session }
    );
    if (!room) throw new ApiError(404, 'Room not found or unavailable');

    const hotel = await Hotel.findById(room.hotel).session(session);
    if (!hotel || !hotel.isActive) throw new ApiError(404, 'Hotel is not available');
    if (guestCount > room.capacity) throw new ApiError(400, `This room sleeps at most ${room.capacity} guest(s)`);

    const units = await availableUnits(room, checkIn, checkOut, session);
    if (units < 1) throw new ApiError(409, 'Sorry, this room is no longer available for the selected dates');

    const [created] = await Booking.create(
      [
        {
          user: req.user._id,
          hotel: hotel._id,
          room: room._id,
          checkIn,
          checkOut,
          guests: guestCount,
          nights,
          pricePerNight: room.pricePerNight,
          totalPrice: nights * room.pricePerNight,
          guestName: guestName || req.user.name,
          guestPhone: guestPhone || req.user.phone,
          specialRequests,
        },
      ],
      { session }
    );
    return created;
  });

  const populated = await populateBooking(Booking.findById(booking._id));
  res.status(201).json({ success: true, message: 'Booking created. Complete payment to confirm it.', booking: populated });
});

// GET /api/bookings/my
exports.getMyBookings = asyncHandler(async (req, res) => {
  await markCompletedBookings();
  const filter = { user: req.user._id };
  if (req.query.status) filter.status = req.query.status;
  const bookings = await populateBooking(Booking.find(filter).sort('-createdAt'));
  res.json({ success: true, bookings });
});

// GET /api/bookings/:id  (owner or admin) - accepts Mongo _id or the HP-... booking ID
exports.getBooking = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const query = /^[0-9a-fA-F]{24}$/.test(id) ? { _id: id } : { bookingId: id };
  const booking = await populateBooking(Booking.findOne(query));
  if (!booking) throw new ApiError(404, 'Booking not found');
  const ownerId = booking.user._id ? booking.user._id : booking.user;
  if (req.user.role !== 'admin' && String(ownerId) !== String(req.user._id)) throw new ApiError(403, 'Not allowed to view this booking');
  const payment = await Payment.findOne({ booking: booking._id }).sort('-createdAt');
  res.json({ success: true, booking, payment });
});

// PATCH /api/bookings/:id/cancel (owner or admin)
exports.cancelBooking = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id);
  if (!booking) throw new ApiError(404, 'Booking not found');
  if (req.user.role !== 'admin' && String(booking.user) !== String(req.user._id)) throw new ApiError(403, 'Not allowed to cancel this booking');
  if (!['pending', 'confirmed'].includes(booking.status)) throw new ApiError(400, `A ${booking.status} booking cannot be cancelled`);
  if (req.user.role !== 'admin' && booking.checkIn < todayUTC()) throw new ApiError(400, 'Past bookings cannot be cancelled');

  booking.status = 'cancelled';
  booking.cancelledAt = new Date();
  await booking.save();

  // Refund automatically if it was paid
  const payment = await Payment.findOne({ booking: booking._id, status: 'successful' });
  if (payment) await refundPayment(payment);

  const fresh = await populateBooking(Booking.findById(booking._id));
  res.json({ success: true, message: payment ? 'Booking cancelled and payment refunded' : 'Booking cancelled', booking: fresh });
});

// ---------------- Admin ----------------

// GET /api/bookings (admin) ?status=&hotel=&search=&page=&limit=
exports.getAllBookings = asyncHandler(async (req, res) => {
  await markCompletedBookings();
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  if (req.query.hotel) filter.hotel = req.query.hotel;
  if (req.query.search) filter.bookingId = new RegExp(req.query.search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  const [bookings, total] = await Promise.all([
    populateBooking(Booking.find(filter).sort('-createdAt').skip((page - 1) * limit).limit(limit)),
    Booking.countDocuments(filter),
  ]);
  res.json({ success: true, total, page, pages: Math.ceil(total / limit) || 1, bookings });
});

// PATCH /api/bookings/:id/status (admin) body: { status }
exports.updateStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  const booking = await Booking.findById(req.params.id);
  if (!booking) throw new ApiError(404, 'Booking not found');
  if (booking.status === 'cancelled') throw new ApiError(400, 'Cancelled bookings cannot be changed');

  if (status === 'cancelled') {
    booking.status = 'cancelled';
    booking.cancelledAt = new Date();
    await booking.save();
    const payment = await Payment.findOne({ booking: booking._id, status: 'successful' });
    if (payment) await refundPayment(payment);
  } else {
    booking.status = status;
    await booking.save();
  }
  res.json({ success: true, booking: await populateBooking(Booking.findById(booking._id)) });
});
