const crypto = require('crypto');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { getRazorpay, isRazorpayEnabled } = require('../config/razorpay');
const { newTxnId, refundPayment } = require('../utils/paymentService');

const markSuccess = async (payment, extra = {}) => {
  Object.assign(payment, extra, { status: 'successful', paidAt: new Date() });
  await payment.save();
  await Booking.findByIdAndUpdate(payment.booking, { status: 'confirmed', paymentStatus: 'successful' });
  return payment;
};

// GET /api/payments/config  (public) - tells the UI which gateway is active
exports.getConfig = (_req, res) => {
  res.json({
    success: true,
    mode: isRazorpayEnabled() ? 'razorpay' : 'simulated',
    keyId: isRazorpayEnabled() ? process.env.RAZORPAY_KEY_ID : null,
  });
};

// POST /api/payments/create-order  { bookingId }
exports.createOrder = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.body.bookingId);
  if (!booking) throw new ApiError(404, 'Booking not found');
  if (String(booking.user) !== String(req.user._id)) throw new ApiError(403, 'Not your booking');
  if (booking.status !== 'pending') throw new ApiError(400, `Booking is already ${booking.status}`);
  if (booking.paymentStatus === 'successful') throw new ApiError(400, 'Booking is already paid');

  const mode = isRazorpayEnabled() ? 'razorpay' : 'simulated';
  let payment = await Payment.findOne({ booking: booking._id, status: 'pending' });
  if (!payment) {
    payment = await Payment.create({ booking: booking._id, user: req.user._id, amount: booking.totalPrice, method: mode });
  }

  if (mode === 'razorpay') {
    const order = await getRazorpay().orders.create({
      amount: Math.round(booking.totalPrice * 100),
      currency: 'INR',
      receipt: booking.bookingId,
    });
    payment.razorpayOrderId = order.id;
    payment.method = 'razorpay';
    await payment.save();
    return res.status(201).json({ success: true, mode, keyId: process.env.RAZORPAY_KEY_ID, order, payment });
  }
  res.status(201).json({ success: true, mode, payment });
});

// POST /api/payments/verify  (Razorpay) { razorpay_order_id, razorpay_payment_id, razorpay_signature }
exports.verifyPayment = asyncHandler(async (req, res) => {
  if (!isRazorpayEnabled()) throw new ApiError(400, 'Razorpay is not configured');
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
  const payment = await Payment.findOne({ razorpayOrderId: razorpay_order_id, user: req.user._id });
  if (!payment) throw new ApiError(404, 'Payment record not found');

  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');
  if (expected !== razorpay_signature) {
    payment.status = 'failed';
    payment.failureReason = 'Signature verification failed';
    await payment.save();
    await Booking.findByIdAndUpdate(payment.booking, { paymentStatus: 'failed' });
    throw new ApiError(400, 'Payment verification failed');
  }
  await markSuccess(payment, { razorpayPaymentId: razorpay_payment_id, transactionId: razorpay_payment_id });
  res.json({ success: true, message: 'Payment successful. Booking confirmed.', payment });
});

// POST /api/payments/simulate  { paymentId, outcome: 'success' | 'failed' }
// SIMULATED GATEWAY - only available when Razorpay is not configured. No card data is ever accepted.
exports.simulatePayment = asyncHandler(async (req, res) => {
  if (isRazorpayEnabled()) throw new ApiError(400, 'Simulated payments are disabled when Razorpay is configured');
  const { paymentId, outcome } = req.body;
  const payment = await Payment.findOne({ _id: paymentId, user: req.user._id });
  if (!payment) throw new ApiError(404, 'Payment not found');
  if (payment.status !== 'pending') throw new ApiError(400, `Payment is already ${payment.status}`);

  if (outcome === 'failed') {
    payment.status = 'failed';
    payment.failureReason = 'Simulated payment failure';
    await payment.save();
    await Booking.findByIdAndUpdate(payment.booking, { paymentStatus: 'failed' });
    return res.json({ success: true, message: 'Payment failed (simulated). You can try again.', payment });
  }
  await markSuccess(payment, { transactionId: newTxnId('SIM') });
  res.json({ success: true, message: 'Payment successful (simulated). Booking confirmed.', payment });
});

// GET /api/payments/my
exports.getMyPayments = asyncHandler(async (req, res) => {
  const payments = await Payment.find({ user: req.user._id })
    .populate({ path: 'booking', select: 'bookingId checkIn checkOut hotel', populate: { path: 'hotel', select: 'name city' } })
    .sort('-createdAt');
  res.json({ success: true, payments });
});

// GET /api/payments (admin) ?status=&page=&limit=
exports.getAllPayments = asyncHandler(async (req, res) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
  const filter = req.query.status ? { status: req.query.status } : {};
  const [payments, total, sums] = await Promise.all([
    Payment.find(filter)
      .populate('user', 'name email')
      .populate({ path: 'booking', select: 'bookingId hotel', populate: { path: 'hotel', select: 'name' } })
      .sort('-createdAt')
      .skip((page - 1) * limit)
      .limit(limit),
    Payment.countDocuments(filter),
    Payment.aggregate([{ $group: { _id: '$status', total: { $sum: '$amount' }, count: { $sum: 1 } } }]),
  ]);
  res.json({ success: true, total, page, pages: Math.ceil(total / limit) || 1, payments, summary: sums });
});

// PATCH /api/payments/:id/refund (admin)
exports.refund = asyncHandler(async (req, res) => {
  const payment = await Payment.findById(req.params.id);
  if (!payment) throw new ApiError(404, 'Payment not found');
  if (payment.status !== 'successful') throw new ApiError(400, 'Only successful payments can be refunded');
  await refundPayment(payment);
  await Booking.findByIdAndUpdate(payment.booking, { status: 'cancelled', cancelledAt: new Date() });
  res.json({ success: true, message: 'Payment refunded and booking cancelled', payment });
});
