const User = require('../models/User');
const Booking = require('../models/Booking');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

// PUT /api/users/profile
exports.updateProfile = asyncHandler(async (req, res) => {
  const { name, phone, address, email } = req.body;
  if (email && email.toLowerCase() !== req.user.email) {
    if (await User.findOne({ email: email.toLowerCase() })) throw new ApiError(409, 'Email is already in use');
    req.user.email = email;
  }
  if (name !== undefined) req.user.name = name;
  if (phone !== undefined) req.user.phone = phone;
  if (address !== undefined) req.user.address = address;
  await req.user.save();
  res.json({ success: true, user: req.user });
});

// PUT /api/users/password
exports.changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = await User.findById(req.user._id).select('+password');
  if (!(await user.comparePassword(currentPassword))) throw new ApiError(400, 'Current password is incorrect');
  user.password = newPassword;
  await user.save();
  res.json({ success: true, message: 'Password updated successfully' });
});

// ---------- Admin: guest management ----------

// GET /api/users?search=&page=&limit=
exports.listCustomers = asyncHandler(async (req, res) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
  const filter = { role: 'customer' };
  if (req.query.search) {
    const rx = new RegExp(req.query.search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    filter.$or = [{ name: rx }, { email: rx }, { phone: rx }];
  }
  const [users, total] = await Promise.all([
    User.find(filter).sort('-createdAt').skip((page - 1) * limit).limit(limit),
    User.countDocuments(filter),
  ]);

  const stats = await Booking.aggregate([
    { $match: { user: { $in: users.map((u) => u._id) } } },
    {
      $group: {
        _id: '$user',
        bookings: { $sum: 1 },
        spent: { $sum: { $cond: [{ $eq: ['$paymentStatus', 'successful'] }, '$totalPrice', 0] } },
      },
    },
  ]);
  const map = new Map(stats.map((s) => [String(s._id), s]));
  const data = users.map((u) => ({
    ...u.toJSON(),
    bookingCount: map.get(String(u._id))?.bookings || 0,
    totalSpent: map.get(String(u._id))?.spent || 0,
  }));
  res.json({ success: true, total, page, pages: Math.ceil(total / limit), users: data });
});

// GET /api/users/:id
exports.getCustomer = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new ApiError(404, 'Customer not found');
  const bookings = await Booking.find({ user: user._id }).populate('hotel', 'name city').populate('room', 'name').sort('-createdAt');
  res.json({ success: true, user, bookings });
});

// PUT /api/users/:id  (admin edits guest record)
exports.updateCustomer = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user || user.role !== 'customer') throw new ApiError(404, 'Customer not found');
  ['name', 'phone', 'address'].forEach((f) => {
    if (req.body[f] !== undefined) user[f] = req.body[f];
  });
  if (req.body.isActive !== undefined) user.isActive = Boolean(req.body.isActive);
  await user.save();
  res.json({ success: true, user });
});
