const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const generateToken = require('../utils/generateToken');

// POST /api/auth/register  (public) - always creates a CUSTOMER
exports.register = asyncHandler(async (req, res) => {
  const { name, email, password, phone } = req.body;
  if (await User.findOne({ email: email.toLowerCase() })) throw new ApiError(409, 'Email is already registered');
  const user = await User.create({ name, email, password, phone, role: 'customer' });
  res.status(201).json({ success: true, token: generateToken(user), user });
});

// POST /api/auth/login (public)
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user || !(await user.comparePassword(password))) throw new ApiError(401, 'Invalid email or password');
  if (!user.isActive) throw new ApiError(403, 'This account has been deactivated');
  res.json({ success: true, token: generateToken(user), user });
});

// POST /api/auth/admin-login (public) - only admins may log in here
exports.adminLogin = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user || !(await user.comparePassword(password))) throw new ApiError(401, 'Invalid email or password');
  if (user.role !== 'admin') throw new ApiError(403, 'This portal is for administrators only');
  if (!user.isActive) throw new ApiError(403, 'This account has been deactivated');
  res.json({ success: true, token: generateToken(user), user });
});

// GET /api/auth/me
exports.me = asyncHandler(async (req, res) => {
  res.json({ success: true, user: req.user });
});
