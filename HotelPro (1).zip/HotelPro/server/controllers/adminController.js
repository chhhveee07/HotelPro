const User = require('../models/User');
const Hotel = require('../models/Hotel');
const Room = require('../models/Room');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const asyncHandler = require('../utils/asyncHandler');
const { todayUTC, MS_DAY, toUTCDate } = require('../utils/dates');
const { markCompletedBookings } = require('../utils/maintenance');
const { ACTIVE_STATUSES } = require('../utils/availability');

// Occupancy over the next `days` days, per hotel and overall. Uses real bookings.
const computeOccupancy = async (days = 30) => {
  const start = todayUTC();
  const end = new Date(start.getTime() + days * MS_DAY);
  const [hotels, rooms, bookings] = await Promise.all([
    Hotel.find({ isActive: true }).select('name city'),
    Room.find({ isActive: true }).select('hotel quantity'),
    Booking.find({ status: { $in: ['confirmed', 'pending', 'completed'] }, checkIn: { $lt: end }, checkOut: { $gt: start } }).select('hotel checkIn checkOut'),
  ]);

  const unitsByHotel = new Map();
  rooms.forEach((r) => unitsByHotel.set(String(r.hotel), (unitsByHotel.get(String(r.hotel)) || 0) + r.quantity));

  const perHotel = hotels.map((h) => {
    const units = unitsByHotel.get(String(h._id)) || 0;
    let nightsBooked = 0;
    let occupiedToday = 0;
    bookings.filter((b) => String(b.hotel) === String(h._id)).forEach((b) => {
      const from = Math.max(b.checkIn.getTime(), start.getTime());
      const to = Math.min(b.checkOut.getTime(), end.getTime());
      nightsBooked += Math.max(Math.round((to - from) / MS_DAY), 0);
      if (b.checkIn.getTime() <= start.getTime() && b.checkOut.getTime() > start.getTime()) occupiedToday += 1;
    });
    const capacityNights = units * days;
    return {
      hotelId: h._id,
      name: h.name,
      city: h.city,
      totalUnits: units,
      occupiedToday,
      todayRate: units ? Math.round((occupiedToday / units) * 100) : 0,
      periodRate: capacityNights ? Math.round((nightsBooked / capacityNights) * 100) : 0,
    };
  });

  const totalUnits = perHotel.reduce((s, h) => s + h.totalUnits, 0);
  const occupiedToday = perHotel.reduce((s, h) => s + h.occupiedToday, 0);
  const totalNights = perHotel.reduce((s, h) => s + (h.periodRate / 100) * h.totalUnits * days, 0);
  return {
    days,
    totalUnits,
    occupiedToday,
    todayRate: totalUnits ? Math.round((occupiedToday / totalUnits) * 100) : 0,
    periodRate: totalUnits ? Math.round((totalNights / (totalUnits * days)) * 100) : 0,
    perHotel,
  };
};

// GET /api/admin/stats
exports.getStats = asyncHandler(async (_req, res) => {
  await markCompletedBookings();
  const today = todayUTC();
  const sixMonthsAgo = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() - 5, 1));

  const [totalHotels, totalRooms, totalCustomers, totalBookings, revenueAgg, statusAgg, monthly, recent, checkInsToday, occupancy, topHotels] =
    await Promise.all([
      Hotel.countDocuments(),
      Room.countDocuments(),
      User.countDocuments({ role: 'customer' }),
      Booking.countDocuments(),
      Payment.aggregate([{ $match: { status: 'successful' } }, { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }]),
      Booking.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
      Payment.aggregate([
        { $match: { status: { $in: ['successful', 'refunded'] }, createdAt: { $gte: sixMonthsAgo } } },
        {
          $group: {
            _id: { y: { $year: '$createdAt' }, m: { $month: '$createdAt' } },
            revenue: { $sum: { $cond: [{ $eq: ['$status', 'successful'] }, '$amount', 0] } },
            bookings: { $sum: 1 },
          },
        },
        { $sort: { '_id.y': 1, '_id.m': 1 } },
      ]),
      Booking.find().populate('hotel', 'name').populate('user', 'name').sort('-createdAt').limit(6),
      Booking.countDocuments({ checkIn: toUTCDate(today), status: { $in: ACTIVE_STATUSES } }),
      computeOccupancy(30),
      Booking.aggregate([
        { $match: { paymentStatus: 'successful' } },
        { $group: { _id: '$hotel', revenue: { $sum: '$totalPrice' }, bookings: { $sum: 1 } } },
        { $sort: { revenue: -1 } },
        { $limit: 5 },
        { $lookup: { from: 'hotels', localField: '_id', foreignField: '_id', as: 'hotel' } },
        { $unwind: '$hotel' },
        { $project: { _id: 0, hotelId: '$_id', name: '$hotel.name', city: '$hotel.city', revenue: 1, bookings: 1 } },
      ]),
    ]);

  // Fill missing months with zero so the chart has 6 continuous points
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthlyRevenue = [];
  for (let i = 5; i >= 0; i -= 1) {
    const d = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() - i, 1));
    const found = monthly.find((x) => x._id.y === d.getUTCFullYear() && x._id.m === d.getUTCMonth() + 1);
    monthlyRevenue.push({ label: `${monthNames[d.getUTCMonth()]} ${String(d.getUTCFullYear()).slice(2)}`, revenue: found ? found.revenue : 0, bookings: found ? found.bookings : 0 });
  }

  res.json({
    success: true,
    stats: {
      totalHotels,
      totalRooms,
      totalCustomers,
      totalBookings,
      totalRevenue: revenueAgg[0]?.total || 0,
      successfulPayments: revenueAgg[0]?.count || 0,
      checkInsToday,
      bookingsByStatus: statusAgg.map((s) => ({ status: s._id, count: s.count })),
      monthlyRevenue,
      occupancy,
      topHotels,
      recentBookings: recent,
    },
  });
});

// GET /api/admin/revenue?from=YYYY-MM-DD&to=YYYY-MM-DD&groupBy=day|month
exports.getRevenueReport = asyncHandler(async (req, res) => {
  const to = req.query.to ? toUTCDate(req.query.to) : todayUTC();
  const from = req.query.from ? toUTCDate(req.query.from) : new Date(to.getTime() - 29 * MS_DAY);
  const endExclusive = new Date(to.getTime() + MS_DAY);
  const fmt = req.query.groupBy === 'month' ? '%Y-%m' : '%Y-%m-%d';

  const [series, totals, byHotel] = await Promise.all([
    Payment.aggregate([
      { $match: { status: 'successful', paidAt: { $gte: from, $lt: endExclusive } } },
      { $group: { _id: { $dateToString: { format: fmt, date: '$paidAt' } }, revenue: { $sum: '$amount' }, payments: { $sum: 1 } } },
      { $sort: { _id: 1 } },
      { $project: { _id: 0, period: '$_id', revenue: 1, payments: 1 } },
    ]),
    Payment.aggregate([
      { $match: { createdAt: { $gte: from, $lt: endExclusive } } },
      { $group: { _id: '$status', total: { $sum: '$amount' }, count: { $sum: 1 } } },
    ]),
    Booking.aggregate([
      { $match: { paymentStatus: 'successful', createdAt: { $gte: from, $lt: endExclusive } } },
      { $group: { _id: '$hotel', revenue: { $sum: '$totalPrice' }, bookings: { $sum: 1 }, nights: { $sum: '$nights' } } },
      { $lookup: { from: 'hotels', localField: '_id', foreignField: '_id', as: 'hotel' } },
      { $unwind: '$hotel' },
      { $project: { _id: 0, hotel: '$hotel.name', city: '$hotel.city', revenue: 1, bookings: 1, nights: 1 } },
      { $sort: { revenue: -1 } },
    ]),
  ]);

  res.json({
    success: true,
    from,
    to,
    series,
    totals: totals.map((t) => ({ status: t._id, total: t.total, count: t.count })),
    byHotel,
  });
});

// GET /api/admin/occupancy?days=30
exports.getOccupancy = asyncHandler(async (req, res) => {
  const days = Math.min(Math.max(parseInt(req.query.days, 10) || 30, 1), 90);
  res.json({ success: true, occupancy: await computeOccupancy(days) });
});
