const fs = require('fs');
const path = require('path');
const Hotel = require('../models/Hotel');
const Room = require('../models/Room');
const Booking = require('../models/Booking');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { parseStay, todayUTC } = require('../utils/dates');
const { availabilityForRooms, ACTIVE_STATUSES } = require('../utils/availability');

const escapeRx = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const parseList = (v) => (Array.isArray(v) ? v : typeof v === 'string' ? v.split(',').map((s) => s.trim()).filter(Boolean) : undefined);

const HOTEL_FIELDS = ['name', 'description', 'city', 'state', 'country', 'address', 'starRating', 'rating', 'featured', 'isActive', 'policies'];

// GET /api/hotels  (public)
// query: search, city, minPrice, maxPrice, rating, stars, sort, featured, checkIn, checkOut, guests, page, limit
exports.getHotels = asyncHandler(async (req, res) => {
  const { search, city, minPrice, maxPrice, rating, featured, sort, checkIn, checkOut, guests } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(parseInt(req.query.limit, 10) || 9, 50);

  const filter = { isActive: true };
  if (city) filter.city = new RegExp(`^${escapeRx(city)}$`, 'i');
  if (search) {
    const rx = new RegExp(escapeRx(search), 'i');
    filter.$or = [{ city: rx }, { name: rx }, { state: rx }, { address: rx }];
  }
  if (minPrice || maxPrice) {
    filter.startingPrice = {};
    if (minPrice) filter.startingPrice.$gte = Number(minPrice);
    if (maxPrice) filter.startingPrice.$lte = Number(maxPrice);
  }
  if (rating) filter.rating = { $gte: Number(rating) };
  if (featured === 'true') filter.featured = true;

  const sortMap = {
    price_asc: { startingPrice: 1 },
    price_desc: { startingPrice: -1 },
    rating: { rating: -1, reviewCount: -1 },
    newest: { createdAt: -1 },
  };
  const sortBy = sortMap[sort] || { featured: -1, rating: -1 };

  // Availability-aware search
  if (checkIn && checkOut) {
    const { checkIn: ci, checkOut: co } = parseStay(checkIn, checkOut);
    const all = await Hotel.find(filter).sort(sortBy);
    const rooms = await Room.find({ hotel: { $in: all.map((h) => h._id) }, isActive: true });
    const avail = await availabilityForRooms(rooms, ci, co);
    const needed = Number(guests) || 1;
    const okHotels = new Set(
      rooms.filter((r) => avail.get(String(r._id)) > 0 && r.capacity >= needed).map((r) => String(r.hotel))
    );
    const matched = all.filter((h) => okHotels.has(String(h._id)));
    const total = matched.length;
    return res.json({
      success: true,
      total,
      page,
      pages: Math.ceil(total / limit) || 1,
      hotels: matched.slice((page - 1) * limit, page * limit),
    });
  }

  const [hotels, total] = await Promise.all([
    Hotel.find(filter).sort(sortBy).skip((page - 1) * limit).limit(limit),
    Hotel.countDocuments(filter),
  ]);
  res.json({ success: true, total, page, pages: Math.ceil(total / limit) || 1, hotels });
});

// GET /api/hotels/destinations  -> popular cities with hotel counts
exports.getDestinations = asyncHandler(async (_req, res) => {
  const destinations = await Hotel.aggregate([
    { $match: { isActive: true } },
    {
      $group: {
        _id: '$city',
        count: { $sum: 1 },
        minPrice: { $min: '$startingPrice' },
        image: { $first: { $arrayElemAt: ['$images', 0] } },
      },
    },
    { $sort: { count: -1, _id: 1 } },
    { $limit: 8 },
    { $project: { _id: 0, city: '$_id', count: 1, minPrice: 1, image: 1 } },
  ]);
  res.json({ success: true, destinations });
});

// GET /api/hotels/admin/all (admin) - includes inactive
exports.getAllHotelsAdmin = asyncHandler(async (_req, res) => {
  const hotels = await Hotel.find().sort('-createdAt');
  const counts = await Room.aggregate([{ $group: { _id: '$hotel', rooms: { $sum: 1 } } }]);
  const map = new Map(counts.map((c) => [String(c._id), c.rooms]));
  res.json({
    success: true,
    hotels: hotels.map((h) => ({ ...h.toObject(), roomCount: map.get(String(h._id)) || 0 })),
  });
});

// GET /api/hotels/:id  (public) -> hotel + rooms (+ availability when dates given)
exports.getHotel = asyncHandler(async (req, res) => {
  const hotel = await Hotel.findById(req.params.id);
  if (!hotel || (!hotel.isActive && req.user?.role !== 'admin')) throw new ApiError(404, 'Hotel not found');
  const rooms = await Room.find({ hotel: hotel._id, isActive: true }).sort('pricePerNight');
  let roomData = rooms.map((r) => r.toObject());
  const { checkIn, checkOut } = req.query;
  if (checkIn && checkOut) {
    const stay = parseStay(checkIn, checkOut);
    const avail = await availabilityForRooms(rooms, stay.checkIn, stay.checkOut);
    roomData = roomData.map((r) => ({ ...r, available: avail.get(String(r._id)) }));
  }
  res.json({ success: true, hotel, rooms: roomData });
});

// POST /api/hotels (admin)
exports.createHotel = asyncHandler(async (req, res) => {
  const data = {};
  HOTEL_FIELDS.forEach((f) => req.body[f] !== undefined && (data[f] = req.body[f]));
  data.amenities = parseList(req.body.amenities) || [];
  data.images = parseList(req.body.images) || [];
  const hotel = await Hotel.create(data);
  res.status(201).json({ success: true, hotel });
});

// PUT /api/hotels/:id (admin)
exports.updateHotel = asyncHandler(async (req, res) => {
  const hotel = await Hotel.findById(req.params.id);
  if (!hotel) throw new ApiError(404, 'Hotel not found');
  HOTEL_FIELDS.forEach((f) => req.body[f] !== undefined && (hotel[f] = req.body[f]));
  if (req.body.amenities !== undefined) hotel.amenities = parseList(req.body.amenities) || [];
  if (req.body.images !== undefined) hotel.images = parseList(req.body.images) || [];
  await hotel.save();
  res.json({ success: true, hotel });
});

// DELETE /api/hotels/:id (admin) - blocked while there are upcoming active bookings
exports.deleteHotel = asyncHandler(async (req, res) => {
  const hotel = await Hotel.findById(req.params.id);
  if (!hotel) throw new ApiError(404, 'Hotel not found');
  const upcoming = await Booking.countDocuments({
    hotel: hotel._id,
    status: { $in: ACTIVE_STATUSES },
    checkOut: { $gt: todayUTC() },
  });
  if (upcoming > 0) throw new ApiError(409, `Cannot delete: ${upcoming} upcoming booking(s). Cancel them or deactivate the hotel instead.`);
  await Room.deleteMany({ hotel: hotel._id });
  await hotel.deleteOne();
  res.json({ success: true, message: 'Hotel and its rooms deleted' });
});

// POST /api/hotels/:id/images (admin, multipart field "images")
exports.uploadImages = asyncHandler(async (req, res) => {
  const hotel = await Hotel.findById(req.params.id);
  if (!hotel) throw new ApiError(404, 'Hotel not found');
  if (!req.files || !req.files.length) throw new ApiError(400, 'No images uploaded');
  hotel.images.push(...req.files.map((f) => `/uploads/${f.filename}`));
  await hotel.save();
  res.status(201).json({ success: true, hotel });
});

// DELETE /api/hotels/:id/images?url=...
exports.removeImage = asyncHandler(async (req, res) => {
  const hotel = await Hotel.findById(req.params.id);
  if (!hotel) throw new ApiError(404, 'Hotel not found');
  const { url } = req.query;
  hotel.images = hotel.images.filter((i) => i !== url);
  await hotel.save();
  if (url && url.startsWith('/uploads/')) {
    fs.unlink(path.join(__dirname, '..', url), () => {});
  }
  res.json({ success: true, hotel });
});
