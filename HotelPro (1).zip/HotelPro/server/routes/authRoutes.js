const router = require('express').Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect } = require('../middleware/auth');
const c = require('../controllers/authController');

const email = body('email').isEmail().withMessage('A valid email is required').normalizeEmail();

router.post(
  '/register',
  [
    body('name').trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters'),
    email,
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('phone').optional({ checkFalsy: true }).matches(/^[0-9+\-\s]{7,15}$/).withMessage('Invalid phone number'),
  ],
  validate,
  c.register
);
router.post('/login', [email, body('password').notEmpty().withMessage('Password is required')], validate, c.login);
router.post('/admin-login', [email, body('password').notEmpty().withMessage('Password is required')], validate, c.adminLogin);
router.get('/me', protect, c.me);

module.exports = router;
