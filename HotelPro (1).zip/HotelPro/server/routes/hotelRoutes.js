const router = require('express').Router();
const { body, param } = require('express-validator');
const validate = require('../middleware/validate');
const upload = require('../middleware/upload');
const { protect, authorize, optionalAuth } = require('../middleware/auth');
const c = require('../controllers/hotelController');
const roomC = require('../controllers/roomController');

const hotelRules = [
  body('name').trim().notEmpty().withMessage('Hotel name is required'),
  body('description').trim().notEmpty().withMessage('Description is required'),
  body('city').trim().notEmpty().withMessage('City is required'),
  body('address').trim().notEmpty().withMessage('Address is required'),
  body('starRating').optional().isInt({ min: 1, max: 5 }).withMessage('Star rating must be 1-5'),
  body('rating').optional().isFloat({ min: 0, max: 5 }).withMessage('Rating must be 0-5'),
];
const updateRules = hotelRules.map((r) => r.optional());
const idRule = param('id').isMongoId().withMessage('Invalid hotel ID');

// Public
router.get('/', c.getHotels);
router.get('/destinations', c.getDestinations);
router.get('/admin/all', protect, authorize('admin'), c.getAllHotelsAdmin);
router.get('/:hotelId/rooms', param('hotelId').isMongoId(), validate, roomC.getRoomsByHotel);
router.get('/:id', idRule, validate, optionalAuth, c.getHotel);

// Admin
router.post('/', protect, authorize('admin'), hotelRules, validate, c.createHotel);
router.put('/:id', protect, authorize('admin'), idRule, updateRules, validate, c.updateHotel);
router.delete('/:id', protect, authorize('admin'), idRule, validate, c.deleteHotel);
router.post('/:id/images', protect, authorize('admin'), idRule, validate, upload.array('images', 8), c.uploadImages);
router.delete('/:id/images', protect, authorize('admin'), idRule, validate, c.removeImage);

module.exports = router;
