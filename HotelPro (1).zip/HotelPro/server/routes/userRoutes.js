const router = require('express').Router();
const { body, param } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/userController');

router.use(protect);

router.put(
  '/profile',
  [
    body('name').optional().trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters'),
    body('email').optional().isEmail().withMessage('Invalid email').normalizeEmail(),
    body('phone').optional({ checkFalsy: true }).matches(/^[0-9+\-\s]{7,15}$/).withMessage('Invalid phone number'),
  ],
  validate,
  c.updateProfile
);
router.put(
  '/password',
  [
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters'),
  ],
  validate,
  c.changePassword
);

// Admin only
router.get('/', authorize('admin'), c.listCustomers);
router.get('/:id', authorize('admin'), param('id').isMongoId(), validate, c.getCustomer);
router.put('/:id', authorize('admin'), param('id').isMongoId(), validate, c.updateCustomer);

module.exports = router;
