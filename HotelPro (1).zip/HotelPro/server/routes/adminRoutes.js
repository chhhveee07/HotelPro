const router = require('express').Router();
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/adminController');

router.use(protect, authorize('admin'));
router.get('/stats', c.getStats);
router.get('/revenue', c.getRevenueReport);
router.get('/occupancy', c.getOccupancy);

module.exports = router;
