const router = require('express').Router();
const { body, param } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/paymentController');

router.get('/config', c.getConfig);
router.use(protect);

router.post('/create-order', body('bookingId').isMongoId().withMessage('Valid booking ID required'), validate, c.createOrder);
router.post(
  '/verify',
  [body('razorpay_order_id').notEmpty(), body('razorpay_payment_id').notEmpty(), body('razorpay_signature').notEmpty()],
  validate,
  c.verifyPayment
);
router.post(
  '/simulate',
  [body('paymentId').isMongoId().withMessage('Valid payment ID required'), body('outcome').isIn(['success', 'failed']).withMessage("Outcome must be 'success' or 'failed'")],
  validate,
  c.simulatePayment
);
router.get('/my', c.getMyPayments);
router.get('/', authorize('admin'), c.getAllPayments);
router.patch('/:id/refund', authorize('admin'), param('id').isMongoId(), validate, c.refund);

module.exports = router;
