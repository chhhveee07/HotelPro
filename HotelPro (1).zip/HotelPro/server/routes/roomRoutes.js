const router = require('express').Router();
const { body, param } = require('express-validator');
const validate = require('../middleware/validate');
const upload = require('../middleware/upload');
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/roomController');

const CATEGORIES = ['Standard', 'Deluxe', 'Suite', 'Executive', 'Family', 'Presidential'];
const roomRules = [
  body('hotel').isMongoId().withMessage('A valid hotel ID is required'),
  body('name').trim().notEmpty().withMessage('Room name is required'),
  body('category').optional().isIn(CATEGORIES).withMessage(`Category must be one of: ${CATEGORIES.join(', ')}`),
  body('pricePerNight').isFloat({ min: 1 }).withMessage('Price per night must be at least 1'),
  body('capacity').optional().isInt({ min: 1, max: 10 }).withMessage('Capacity must be 1-10'),
  body('quantity').optional().isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
];
const updateRules = roomRules.map((r) => r.optional());
const idRule = param('id').isMongoId().withMessage('Invalid room ID');

router.get('/:id/availability', idRule, validate, c.checkAvailability);
router.get('/:id', idRule, validate, c.getRoom);

router.use(protect, authorize('admin'));
router.get('/', c.getAllRooms);
router.post('/', roomRules, validate, c.createRoom);
router.put('/:id', idRule, updateRules, validate, c.updateRoom);
router.patch('/:id/price', idRule, body('pricePerNight').isFloat({ min: 1 }).withMessage('Price must be at least 1'), validate, c.updatePrice);
router.delete('/:id', idRule, validate, c.deleteRoom);
router.post('/:id/images', idRule, validate, upload.array('images', 8), c.uploadImages);

module.exports = router;
