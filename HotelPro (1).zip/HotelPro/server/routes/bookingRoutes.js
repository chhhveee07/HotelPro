const router = require('express').Router();
const { body, param } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/bookingController');

router.use(protect);

router.post(
  '/',
  [
    body('roomId').isMongoId().withMessage('A valid room ID is required'),
    body('checkIn').isISO8601().withMessage('Valid check-in date required (YYYY-MM-DD)'),
    body('checkOut').isISO8601().withMessage('Valid check-out date required (YYYY-MM-DD)'),
    body('guests').isInt({ min: 1, max: 10 }).withMessage('Guests must be between 1 and 10'),
    body('guestName').optional({ checkFalsy: true }).trim().isLength({ min: 2, max: 80 }),
    body('guestPhone').optional({ checkFalsy: true }).matches(/^[0-9+\-\s]{7,15}$/).withMessage('Invalid phone number'),
    body('specialRequests').optional().isLength({ max: 500 }).withMessage('Special requests max 500 characters'),
  ],
  validate,
  c.createBooking
);

router.get('/my', c.getMyBookings);
router.get('/', authorize('admin'), c.getAllBookings);
router.get('/:id', c.getBooking);
router.patch('/:id/cancel', param('id').isMongoId(), validate, c.cancelBooking);
router.patch(
  '/:id/status',
  authorize('admin'),
  param('id').isMongoId(),
  body('status').isIn(['pending', 'confirmed', 'cancelled', 'completed']).withMessage('Invalid status'),
  validate,
  c.updateStatus
);

module.exports = router;
