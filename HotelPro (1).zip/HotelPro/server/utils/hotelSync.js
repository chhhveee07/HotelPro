const Hotel = require('../models/Hotel');
const Room = require('../models/Room');

// Keep hotel.startingPrice = cheapest active room.
const syncHotelStartingPrice = async (hotelId) => {
  const cheapest = await Room.find({ hotel: hotelId, isActive: true }).sort('pricePerNight').limit(1);
  await Hotel.findByIdAndUpdate(hotelId, { startingPrice: cheapest[0] ? cheapest[0].pricePerNight : 0 });
};

module.exports = { syncHotelStartingPrice };
