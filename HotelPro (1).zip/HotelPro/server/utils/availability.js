const mongoose = require('mongoose');
const Booking = require('../models/Booking');
const { eachNight } = require('./dates');

// Bookings in these states hold inventory.
const ACTIVE_STATUSES = ['pending', 'confirmed'];

/**
 * Units of a room still free for EVERY night in [checkIn, checkOut).
 * Two stays overlap when: existing.checkIn < new.checkOut AND existing.checkOut > new.checkIn
 * (check-out day is free for the next guest's check-in).
 */
const availableUnits = async (room, checkIn, checkOut, session = null) => {
  const overlapping = await Booking.find({
    room: room._id,
    status: { $in: ACTIVE_STATUSES },
    checkIn: { $lt: checkOut },
    checkOut: { $gt: checkIn },
  })
    .select('checkIn checkOut')
    .session(session);

  let peak = 0;
  for (const night of eachNight(checkIn, checkOut)) {
    const t = night.getTime();
    const used = overlapping.filter((b) => b.checkIn.getTime() <= t && b.checkOut.getTime() > t).length;
    if (used > peak) peak = used;
  }
  return Math.max(room.quantity - peak, 0);
};

// Bulk version used by listings: returns Map(roomId string -> available units)
const availabilityForRooms = async (rooms, checkIn, checkOut) => {
  const ids = rooms.map((r) => r._id);
  const overlapping = await Booking.find({
    room: { $in: ids },
    status: { $in: ACTIVE_STATUSES },
    checkIn: { $lt: checkOut },
    checkOut: { $gt: checkIn },
  }).select('room checkIn checkOut');

  const byRoom = new Map();
  overlapping.forEach((b) => {
    const k = String(b.room);
    if (!byRoom.has(k)) byRoom.set(k, []);
    byRoom.get(k).push(b);
  });

  const nights = eachNight(checkIn, checkOut);
  const result = new Map();
  rooms.forEach((room) => {
    const list = byRoom.get(String(room._id)) || [];
    let peak = 0;
    nights.forEach((n) => {
      const t = n.getTime();
      const used = list.filter((b) => b.checkIn.getTime() <= t && b.checkOut.getTime() > t).length;
      if (used > peak) peak = used;
    });
    result.set(String(room._id), Math.max(room.quantity - peak, 0));
  });
  return result;
};

/**
 * Run `fn(session)` inside a MongoDB transaction. On standalone MongoDB (no replica set,
 * transactions unsupported) it falls back to running without a session.
 * MongoDB Atlas always supports transactions.
 */
const runInTransaction = async (fn) => {
  const session = await mongoose.startSession();
  try {
    let result;
    await session.withTransaction(async () => {
      result = await fn(session);
    });
    return result;
  } catch (err) {
    const unsupported =
      err && (err.code === 20 || /replica set|Transaction numbers/i.test(err.message || ''));
    if (unsupported) {
      console.warn('[warn] Transactions unsupported on this MongoDB; running without one.');
      return fn(null);
    }
    throw err;
  } finally {
    session.endSession();
  }
};

module.exports = { ACTIVE_STATUSES, availableUnits, availabilityForRooms, runInTransaction };
