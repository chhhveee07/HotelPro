const ApiError = require('./ApiError');

const MS_DAY = 24 * 60 * 60 * 1000;
const MAX_NIGHTS = 30;

// Parse "YYYY-MM-DD" (or ISO) into a UTC-midnight Date.
const toUTCDate = (value) => {
  if (!value) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
};

const todayUTC = () => {
  const n = new Date();
  return new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate()));
};

const nightsBetween = (checkIn, checkOut) => Math.round((checkOut - checkIn) / MS_DAY);

// Validates and normalises a stay. Throws ApiError(400) for bad input.
const parseStay = (checkInRaw, checkOutRaw, { allowPast = false } = {}) => {
  const checkIn = toUTCDate(checkInRaw);
  const checkOut = toUTCDate(checkOutRaw);
  if (!checkIn || !checkOut) throw new ApiError(400, 'Valid check-in and check-out dates are required');
  if (!allowPast && checkIn < todayUTC()) throw new ApiError(400, 'Check-in date cannot be in the past');
  if (checkOut <= checkIn) throw new ApiError(400, 'Check-out must be after check-in');
  const nights = nightsBetween(checkIn, checkOut);
  if (nights > MAX_NIGHTS) throw new ApiError(400, `Maximum stay is ${MAX_NIGHTS} nights`);
  return { checkIn, checkOut, nights };
};

// Every night date in [checkIn, checkOut)
const eachNight = (checkIn, checkOut) => {
  const out = [];
  for (let t = checkIn.getTime(); t < checkOut.getTime(); t += MS_DAY) out.push(new Date(t));
  return out;
};

module.exports = { MS_DAY, MAX_NIGHTS, toUTCDate, todayUTC, nightsBetween, parseStay, eachNight };
