const Booking = require('../models/Booking');
const { todayUTC } = require('./dates');

// Confirmed bookings whose check-out date has passed become "completed".
const markCompletedBookings = async () => {
  const res = await Booking.updateMany(
    { status: 'confirmed', checkOut: { $lte: todayUTC() } },
    { $set: { status: 'completed' } }
  );
  return res.modifiedCount;
};

module.exports = { markCompletedBookings };
