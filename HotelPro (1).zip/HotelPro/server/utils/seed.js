/* Seed script:  npm run seed          -> wipes data and inserts sample data
 *               npm run seed:destroy  -> wipes data only                    */
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Hotel = require('../models/Hotel');
const Room = require('../models/Room');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const { todayUTC, MS_DAY } = require('./dates');

const img = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1200&q=70`;
const ROOM_IMGS = [
  img('photo-1582719478250-c89cae4dc85b'),
  img('photo-1618773928121-c32242e63f39'),
  img('photo-1611892440504-42a792e24d32'),
  img('photo-1590490360182-c33d57733427'),
  img('photo-1578683010236-d716f9a3f461'),
];

const hotels = [
  { name: 'The Marine Crown', city: 'Mumbai', state: 'Maharashtra', address: 'Marine Drive, Churchgate, Mumbai 400020', starRating: 5, rating: 4.8, reviewCount: 842, featured: true,
    description: 'A landmark sea-facing hotel on Marine Drive with art-deco interiors, a rooftop lounge and views across the Arabian Sea.',
    amenities: ['Free WiFi', 'Pool', 'Spa', 'Restaurant', 'Gym', 'Airport Shuttle', 'Bar'],
    images: [img('photo-1566073771259-6a8506099945'), img('photo-1542314831-068cd1dbfeeb'), img('photo-1551882547-ff40c63fe5fa')],
    rooms: [['Classic Sea View', 'Standard', 6500, 2, 8], ['Deluxe Bay Room', 'Deluxe', 9800, 3, 5], ['Crown Suite', 'Suite', 18500, 4, 2]] },
  { name: 'Palm Cove Resort', city: 'Goa', state: 'Goa', address: 'Candolim Beach Road, North Goa 403515', starRating: 5, rating: 4.7, reviewCount: 615, featured: true,
    description: 'Beachfront resort set in coconut groves with a lagoon pool, Goan seafood restaurant and sunset yoga on the sand.',
    amenities: ['Free WiFi', 'Beach Access', 'Pool', 'Spa', 'Restaurant', 'Bar', 'Yoga'],
    images: [img('photo-1520250497591-112f2f40a3f4'), img('photo-1445019980597-93fa8acb246c'), img('photo-1571896349842-33c89424de2d')],
    rooms: [['Garden Cottage', 'Standard', 5200, 2, 10], ['Lagoon Deluxe', 'Deluxe', 8200, 3, 6], ['Beach Villa', 'Suite', 15500, 5, 3]] },
  { name: 'Amber Fort Haveli', city: 'Jaipur', state: 'Rajasthan', address: 'Amer Road, Jaipur 302002', starRating: 4, rating: 4.6, reviewCount: 430, featured: true,
    description: 'A restored 18th-century haveli with painted courtyards, rooftop dining facing Amer Fort and folk music in the evenings.',
    amenities: ['Free WiFi', 'Restaurant', 'Courtyard', 'Cultural Shows', 'Airport Shuttle'],
    images: [img('photo-1564501049412-61c2a3083791'), img('photo-1584132967334-10e028bd69f7'), img('photo-1455587734955-081b22074882')],
    rooms: [['Courtyard Room', 'Standard', 3800, 2, 8], ['Heritage Deluxe', 'Deluxe', 5900, 3, 5], ['Maharaja Suite', 'Suite', 11000, 4, 2]] },
  { name: 'Lake Pichola Palace View', city: 'Udaipur', state: 'Rajasthan', address: 'Lake Palace Road, Udaipur 313001', starRating: 5, rating: 4.9, reviewCount: 701, featured: true,
    description: 'Lake-facing luxury hotel with marble terraces, a candle-lit rooftop restaurant and boat transfers to the City Palace.',
    amenities: ['Free WiFi', 'Lake View', 'Pool', 'Spa', 'Restaurant', 'Butler Service'],
    images: [img('photo-1584132967334-10e028bd69f7'), img('photo-1566073771259-6a8506099945'), img('photo-1542314831-068cd1dbfeeb')],
    rooms: [['Lake Facing Room', 'Deluxe', 12000, 2, 6], ['Royal Suite', 'Suite', 22000, 4, 3], ['Presidential Palace Suite', 'Presidential', 45000, 6, 1]] },
  { name: 'Connaught Grand', city: 'Delhi', state: 'Delhi', address: 'Barakhamba Road, Connaught Place, New Delhi 110001', starRating: 5, rating: 4.5, reviewCount: 980,
    description: 'A business-friendly hotel in the heart of New Delhi, minutes from Metro stations, with meeting rooms and an all-day diner.',
    amenities: ['Free WiFi', 'Business Center', 'Gym', 'Restaurant', 'Airport Shuttle', 'Bar'],
    images: [img('photo-1551882547-ff40c63fe5fa'), img('photo-1571896349842-33c89424de2d'), img('photo-1455587734955-081b22074882')],
    rooms: [['Business Room', 'Standard', 5500, 2, 12], ['Executive King', 'Executive', 8800, 2, 8], ['Capital Suite', 'Suite', 16000, 4, 2]] },
  { name: 'Garden City Boutique', city: 'Bengaluru', state: 'Karnataka', address: '12 Church Street, MG Road, Bengaluru 560001', starRating: 4, rating: 4.4, reviewCount: 356,
    description: 'A design-led boutique hotel near MG Road with a plant-filled atrium, specialty coffee bar and co-working lounge.',
    amenities: ['Free WiFi', 'Co-working', 'Cafe', 'Gym', 'Pet Friendly'],
    images: [img('photo-1542314831-068cd1dbfeeb'), img('photo-1455587734955-081b22074882'), img('photo-1551882547-ff40c63fe5fa')],
    rooms: [['Studio Room', 'Standard', 4200, 2, 10], ['Garden Deluxe', 'Deluxe', 6400, 3, 6], ['Loft Suite', 'Suite', 10500, 4, 2]] },
  { name: 'Himalayan Pine Lodge', city: 'Manali', state: 'Himachal Pradesh', address: 'Old Manali Road, Manali 175131', starRating: 4, rating: 4.6, reviewCount: 288, featured: true,
    description: 'Wooden mountain lodge among deodar pines with valley views, bonfire evenings and guided treks from the doorstep.',
    amenities: ['Free WiFi', 'Bonfire', 'Mountain View', 'Restaurant', 'Trekking', 'Heater'],
    images: [img('photo-1445019980597-93fa8acb246c'), img('photo-1520250497591-112f2f40a3f4'), img('photo-1564501049412-61c2a3083791')],
    rooms: [['Pine Cabin', 'Standard', 3200, 2, 8], ['Valley View Deluxe', 'Deluxe', 5200, 3, 5], ['Family Chalet', 'Family', 8600, 6, 3]] },
  { name: 'Backwater Serenity', city: 'Kochi', state: 'Kerala', address: 'Fort Kochi Waterfront, Kochi 682001', starRating: 4, rating: 4.3, reviewCount: 241,
    description: 'Waterfront heritage stay in Fort Kochi with Kerala cuisine, Ayurvedic massages and sunset houseboat cruises.',
    amenities: ['Free WiFi', 'Ayurveda Spa', 'Restaurant', 'Boat Cruise', 'Pool'],
    images: [img('photo-1571896349842-33c89424de2d'), img('photo-1520250497591-112f2f40a3f4'), img('photo-1566073771259-6a8506099945')],
    rooms: [['Heritage Room', 'Standard', 3900, 2, 8], ['Waterfront Deluxe', 'Deluxe', 6100, 3, 5], ['Kerala Suite', 'Suite', 9800, 4, 2]] },
];

const run = async () => {
  await connectDB();
  await Promise.all([User.deleteMany(), Hotel.deleteMany(), Room.deleteMany(), Booking.deleteMany(), Payment.deleteMany()]);
  console.log('Existing data cleared');
  if (process.argv.includes('--destroy')) return;

  // ---- Users ----
  const admin = await User.create({ name: 'HotelPro Admin', email: process.env.ADMIN_EMAIL || 'admin@hotelpro.com', password: process.env.ADMIN_PASSWORD || 'Admin@12345', role: 'admin', phone: '9000000000' });
  const customers = await Promise.all(
    [
      ['Aarav Sharma', 'aarav@example.com', '9876543210'],
      ['Priya Verma', 'priya@example.com', '9876543211'],
      ['Rohan Mehta', 'rohan@example.com', '9876543212'],
      ['Sneha Iyer', 'sneha@example.com', '9876543213'],
    ].map(([name, email, phone]) => User.create({ name, email, phone, password: 'Customer@123', role: 'customer' }))
  );

  // ---- Hotels & rooms ----
  const roomDocs = [];
  for (const h of hotels) {
    const { rooms, ...data } = h;
    const hotel = await Hotel.create({ ...data, startingPrice: Math.min(...rooms.map((r) => r[2])) });
    for (let i = 0; i < rooms.length; i += 1) {
      const [name, category, pricePerNight, capacity, quantity] = rooms[i];
      const room = await Room.create({
        hotel: hotel._id, name, category, pricePerNight, capacity, quantity,
        description: `${name} at ${hotel.name}: comfortable ${category.toLowerCase()} accommodation with premium bedding and daily housekeeping.`,
        bedType: capacity > 3 ? 'King + Sofa bed' : capacity === 3 ? 'King' : 'Queen',
        sizeSqFt: 220 + i * 130,
        amenities: ['Air Conditioning', 'Free WiFi', 'Smart TV', 'Mini Bar', 'Room Service'],
        images: [ROOM_IMGS[(i + roomDocs.length) % ROOM_IMGS.length], ROOM_IMGS[(i + roomDocs.length + 1) % ROOM_IMGS.length]],
      });
      roomDocs.push(room);
    }
  }

  // ---- Sample bookings + payments (past months and upcoming) so dashboards have real data ----
  const today = todayUTC();
  const samples = [
    // [dayOffsetFromToday, nights, status, paid]
    [-150, 2, 'completed', true], [-130, 3, 'completed', true], [-110, 1, 'completed', true],
    [-95, 4, 'completed', true], [-80, 2, 'completed', true], [-62, 3, 'completed', true],
    [-45, 2, 'completed', true], [-33, 5, 'completed', true], [-20, 2, 'completed', true],
    [-9, 2, 'completed', true], [-2, 4, 'confirmed', true], [3, 2, 'confirmed', true],
    [7, 3, 'confirmed', true], [12, 2, 'pending', false], [18, 4, 'confirmed', true], [-60, 2, 'cancelled', false],
  ];
  let n = 0;
  for (const [offset, nights, status, paid] of samples) {
    const room = roomDocs[(n * 3 + 1) % roomDocs.length];
    const user = customers[n % customers.length];
    const checkIn = new Date(today.getTime() + offset * MS_DAY);
    const checkOut = new Date(checkIn.getTime() + nights * MS_DAY);
    const total = nights * room.pricePerNight;
    const booking = await Booking.create({
      user: user._id, hotel: room.hotel, room: room._id, checkIn, checkOut, nights, guests: Math.min(2, room.capacity),
      pricePerNight: room.pricePerNight, totalPrice: total, status, paymentStatus: paid ? 'successful' : status === 'cancelled' ? 'refunded' : 'pending',
      guestName: user.name, guestPhone: user.phone, createdAt: new Date(checkIn.getTime() - 5 * MS_DAY),
    });
    if (paid || status === 'cancelled') {
      const paidAt = new Date(checkIn.getTime() - 5 * MS_DAY);
      await Payment.create({
        booking: booking._id, user: user._id, amount: total, method: 'simulated',
        status: paid ? 'successful' : 'refunded', transactionId: `SIM-SEED-${n}`, paidAt,
        refundedAt: paid ? undefined : paidAt, createdAt: paidAt,
      });
    }
    n += 1;
  }

  console.log(`Seeded: 1 admin, ${customers.length} customers, ${hotels.length} hotels, ${roomDocs.length} rooms, ${samples.length} bookings`);
  console.log(`\nAdmin login    : ${admin.email} / ${process.env.ADMIN_PASSWORD || 'Admin@12345'}`);
  console.log('Customer login : aarav@example.com / Customer@123');
};

run()
  .catch((e) => { console.error(e); process.exitCode = 1; })
  .finally(() => mongoose.disconnect());
