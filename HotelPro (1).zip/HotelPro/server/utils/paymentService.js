const crypto = require('crypto');
const Payment = require('../models/Payment');
const Booking = require('../models/Booking');
const { getRazorpay } = require('../config/razorpay');

const newTxnId = (prefix) => `${prefix}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

// Refund a successful payment (Razorpay API if applicable, otherwise simulated).
const refundPayment = async (payment) => {
  if (!payment || payment.status !== 'successful') return payment;
  if (payment.method === 'razorpay' && payment.razorpayPaymentId) {
    const rzp = getRazorpay();
    if (rzp) await rzp.payments.refund(payment.razorpayPaymentId, { amount: Math.round(payment.amount * 100) });
  }
  payment.status = 'refunded';
  payment.refundedAt = new Date();
  await payment.save();
  await Booking.findByIdAndUpdate(payment.booking, { paymentStatus: 'refunded' });
  return payment;
};

module.exports = { newTxnId, refundPayment };
