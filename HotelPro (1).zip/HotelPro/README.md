# HotelPro: Complete Hotel Booking and Management Solution

A full-stack MERN application where customers search hotels, check live room availability, book, pay and manage reservations, and administrators run hotels, rooms, guests, payments and reports from a dashboard.

> Academic project. Payments run through **Razorpay test mode** when keys are provided, otherwise through a **clearly labelled simulated gateway**. No real money moves and card details are never stored.

## 1. Problem statement
Small and mid-size hotels often manage reservations in spreadsheets or by phone. This causes double bookings, no live view of room availability, manual payment tracking and no reliable revenue or occupancy numbers. Travellers, in turn, cannot easily compare hotels, see which rooms are free for their dates, or manage bookings and cancellations online.

## 2. Objectives
- Provide a customer portal for searching, filtering, booking, paying and cancelling.
- Prevent double bookings with server-side date-overlap checks inside database transactions.
- Give administrators one console for hotels, rooms, prices, reservations, guests and payments.
- Report revenue and occupancy from real database records.
- Secure the system with JWT authentication, bcrypt hashing and role-based authorization.

## 3. Proposed solution
A React single-page app talks to a REST API built with Express. MongoDB (via Mongoose) stores users, hotels, rooms, bookings and payments. The API enforces every business rule (availability, ownership, roles); the UI only presents it.

## 4. Features
**Customer:** register, login, logout, JWT sessions; search by city/name; filter by price and rating; sort; view hotel details and room categories; availability check for chosen dates; guest count validation; booking with unique ID (`HP-YYYYMMDD-XXXXX`); pay (Razorpay test or simulated); booking history with status filters; cancel with automatic refund of paid bookings; payment history; profile and password management.

**Admin:** separate login (`/admin/login`) and sidebar console; dashboard cards, revenue chart, booking-status chart, occupancy bars, top hotels; add/edit/delete hotels; upload images; add/edit/delete rooms; edit prices inline; manage reservations and statuses; view and edit guest records, deactivate accounts; payment records and refunds; revenue report by date range; occupancy report.

## 5. Technology stack
| Layer | Technology |
|---|---|
| Frontend | React 18, JavaScript, HTML5, CSS3, Bootstrap 5, React Router DOM 6, Axios, Vite |
| Backend | Node.js, Express, REST API, JWT (`jsonwebtoken`), `bcryptjs`, `express-validator`, `helmet`, `cors`, `express-rate-limit`, `multer` |
| Database | MongoDB, Mongoose |
| Payments | Razorpay (test mode) or simulated gateway |

## 6. System architecture
```
 Browser (React SPA, Vercel)
        |  HTTPS, JSON, Bearer JWT (Axios)
        v
 Express API (Render)
   routes -> middleware (auth, role, validation, upload) -> controllers -> models/utils
        |
        v
 MongoDB Atlas (Mongoose)           Razorpay (optional)
```
```
server/
  config/        db.js, razorpay.js
  models/        User, Hotel, Room, Booking, Payment
  controllers/   auth, user, hotel, room, booking, payment, admin
  routes/        one router per resource, with validation rules
  middleware/    auth (protect/authorize), error, validate, upload
  utils/         dates, availability (+transaction helper), seed, payment service
  tests/         dates.test.js (unit), smoke.js (API end-to-end)
  server.js
client/src/
  components/ pages/ services/ context/ assets/  App.jsx main.jsx index.css
docs/            API.md, DEPLOYMENT.md, Postman collection
```

## 7. Database structure
```
User 1---* Booking *---1 Room *---1 Hotel
              |  1
              |  *
           Payment (also references User)
```
| Collection | Key fields |
|---|---|
| **User** | name, email (unique), password (bcrypt, never returned), phone, address, role (`customer`/`admin`), isActive, timestamps |
| **Hotel** | name, description, city, state, country, address, images[], amenities[], starRating, rating, reviewCount, startingPrice (synced from rooms), featured, isActive, policies |
| **Room** | hotel→Hotel, name, category, pricePerNight, capacity, quantity (units of this type), bedType, sizeSqFt, amenities[], images[], isActive |
| **Booking** | bookingId (unique), user→User, hotel→Hotel, room→Room, checkIn, checkOut, nights, guests, pricePerNight, totalPrice, status (`pending/confirmed/completed/cancelled`), paymentStatus, guestName, guestPhone, specialRequests |
| **Payment** | booking→Booking, user→User, amount, currency, method (`razorpay/simulated`), status (`pending/successful/failed/refunded`), transactionId, razorpay ids, paidAt, refundedAt |

All collections use Mongoose validation and `timestamps`.

## 8. Installation
Requirements: Node.js 18+, npm, MongoDB (local) or a free MongoDB Atlas cluster.

```bash
git clone <your-repo-url> && cd HotelPro

# Backend
cd server
npm install
cp .env.example .env     # edit MONGO_URI and JWT_SECRET
npm run seed             # sample data
npm run dev              # API on http://localhost:5000

# Frontend, in another terminal
cd client
npm install
cp .env.example .env
npm run dev              # app on http://localhost:5173
```
Seeded accounts: admin `admin@hotelpro.com` / `Admin@12345` (open `/admin/login`), customer `aarav@example.com` / `Customer@123`. Change the admin password in `.env` before seeding anything public.

Environment variables are documented in `server/.env.example` and `client/.env.example`. Atlas, GitHub, Render and Vercel steps are in [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md).

## 9. Booking and payment flow
1. Customer picks dates on the hotel page; rooms show live availability.
2. Customer confirms a room → `POST /api/bookings` creates a **pending** booking and returns the booking ID. The room is held.
3. Customer pays → payment record created. Success sets booking **confirmed**; failure keeps it pending and retryable.
4. Cancelling a paid booking refunds the payment (status `refunded`). Confirmed bookings past check-out become `completed` automatically.

Double-booking protection (see [docs/API.md](docs/API.md)): backend date-overlap check per night against the room's `quantity`, executed inside a MongoDB transaction that first touches the room document so concurrent requests serialize.

## 10. API documentation
Full endpoint reference: [docs/API.md](docs/API.md). Postman collection: `docs/HotelPro.postman_collection.json` (import it; run folders in order; the collection stores tokens and IDs automatically).

## 11. Testing
| Test | How | What it covers |
|---|---|---|
| Unit | `cd server && npm test` | Date parsing, night counting, past/invalid/too-long stays |
| API smoke test | start server with seeded DB, then `cd server && npm run test:api` | Register/login, validation errors, 401/403, hotel search and filters, availability, booking, **parallel booking race (no double booking)**, payment, cancel + refund, admin stats |
| Postman | import the collection | 39 requests with assertions |
| Manual UI checklist | below | Frontend workflows |

**Manual checklist:** register → login → search "Goa" → filter by price/rating → open hotel → change dates and watch availability → book → pay (simulate success) → see *confirmed* in My Bookings → cancel → see refund in Payment history → edit profile → log out. Then `/admin/login` → dashboard numbers → add hotel → add room → change a price → upload an image → mark a booking completed → refund a payment → view Reports.

**Honest testing note:** the code was generated in an environment with no MongoDB server and no internet, so the unit tests were run, the React client was bundled successfully (all imports resolved), and every backend file was syntax-checked, but the API smoke test and Postman collection could not be executed there. Run `npm run seed`, start the server and run `npm run test:api` on your machine; fix anything it reports before your demo.

## 12. Security
bcrypt (12 rounds); JWT with expiry; role middleware (`authorize('admin')`) on all admin routes; ownership checks on bookings/payments; `express-validator` on inputs; Mongoose validation; regex input escaping; `helmet`; CORS restricted to `CLIENT_URL`; rate limit on `/api/auth`; secrets only in environment variables; password hash never serialized; uploads limited to images up to 5 MB; Razorpay signatures verified server-side; no card data stored.

## 13. Future scope
Guest reviews and ratings; coupon codes (the offers on the home page are display-only samples); email/SMS confirmations; cloud image storage (Cloudinary/S3); calendar view of room occupancy; seasonal and dynamic pricing; automatic expiry of unpaid pending bookings; multi-property staff roles; invoices as PDF; Google/OTP login; automated frontend tests; Docker deployment.
